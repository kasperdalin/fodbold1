import requests
import json
from datetime import datetime, timedelta
from stadium_locations import get_stadium_location

API_KEY = "c73c66550b764bce8ae224549250406"  # Indsæt din API key
BASE_URL = "http://api.weatherapi.com/v1/forecast.json"

def get_weather_for_match(home_team, match_date):
    """
    Hent vejr data for en specifik kamp
    
    Args:
        home_team (str): Hjemmeholdets navn
        match_date (str): Kampdato i format "2025-06-15T15:00:00Z"
    
    Returns:
        dict: Vejr features eller None hvis fejl
    """
    
    # Get stadium location
    location = get_stadium_location(home_team)
    if location == "Unknown":
        print(f"⚠️ Ukendt lokation for {home_team}")
        return None
    
    # Parse match date
    try:
        match_datetime = datetime.fromisoformat(match_date.replace('Z', '+00:00'))
        date_str = match_datetime.strftime('%Y-%m-%d')
    except:
        print(f"❌ Kunne ikke parse dato: {match_date}")
        return None
    
    # API request
    try:
        params = {
            'key': API_KEY,
            'q': location,
            'dt': date_str,
            'aqi': 'no'
        }
        
        response = requests.get(BASE_URL, params=params)
        response.raise_for_status()
        data = response.json()
        
        # Extract weather features
        forecast_day = data['forecast']['forecastday'][0]['day']
        
        weather_features = {
            'temperature_avg': forecast_day['avgtemp_c'],
            'temperature_max': forecast_day['maxtemp_c'],
            'temperature_min': forecast_day['mintemp_c'],
            'wind_speed': forecast_day['maxwind_kph'],
            'precipitation': forecast_day['totalprecip_mm'],
            'humidity': forecast_day['avghumidity'],
            'visibility': forecast_day['avgvis_km'],
            'uv_index': forecast_day['uv'],
            'condition': forecast_day['condition']['text']
        }
        
        print(f"✅ Vejr hentet for {home_team} ({location}): {weather_features['condition']}")
        return weather_features
        
    except Exception as e:
        print(f"❌ Fejl ved vejr API for {home_team}: {e}")
        return None

def add_weather_features(weather_data):
    """
    Konverter råt vejr data til ML features
    
    Args:
        weather_data (dict): Råt vejr data
    
    Returns:
        dict: ML-klar features
    """
    
    if not weather_data:
        return {
            'weather_temperature': 15,  # Default values
            'weather_wind': 10,
            'weather_rain': 0,
            'weather_humidity': 60,
            'weather_poor_conditions': 0
        }
    
    # Create ML features
    features = {
        'weather_temperature': weather_data['temperature_avg'],
        'weather_wind': weather_data['wind_speed'], 
        'weather_rain': weather_data['precipitation'],
        'weather_humidity': weather_data['humidity'],
        'weather_visibility': weather_data['visibility']
    }
    
    # Add derived features
    features['weather_poor_conditions'] = 0
    
    # Poor weather conditions (these typically reduce goals)
    if (weather_data['precipitation'] > 5 or          # Heavy rain
        weather_data['wind_speed'] > 25 or           # Strong wind  
        weather_data['visibility'] < 5 or            # Poor visibility
        weather_data['temperature_avg'] < 2 or       # Very cold
        weather_data['temperature_avg'] > 35):       # Very hot
        
        features['weather_poor_conditions'] = 1
    
    # Extreme weather flag
    features['weather_extreme'] = 0
    if (weather_data['precipitation'] > 15 or         # Very heavy rain
        weather_data['wind_speed'] > 40 or           # Very strong wind
        weather_data['temperature_avg'] < -2 or      # Freezing
        weather_data['temperature_avg'] > 40):       # Extreme heat
        
        features['weather_extreme'] = 1
    
    return features

# Test function
if __name__ == "__main__":
    # Test med en kamp
    test_weather = get_weather_for_match("Arsenal FC", "2025-06-15T15:00:00Z")
    if test_weather:
        features = add_weather_features(test_weather)
        print("\n🌦️ Weather Features:")
        for key, value in features.items():
            print(f"  {key}: {value}")