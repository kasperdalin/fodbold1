import requests
import json
import re
import os
from datetime import datetime
from bs4 import BeautifulSoup

OUT_PATH = "data/xg_stats.json"

LIGAER = {
    "EPL": "Premier League",
    "La_liga": "La Liga", 
    "Bundesliga": "Bundesliga",
    "Serie_A": "Serie A",
    "Ligue_1": "Ligue 1"
}

# EXTENDED name mapping for better team matching
custom_name_map = {
    # Premier League
    "Man Utd": "Manchester United FC",
    "Man City": "Manchester City FC", 
    "Spurs": "Tottenham Hotspur FC",
    "Newcastle": "Newcastle United FC",
    "Wolves": "Wolverhampton Wanderers FC",
    "Brighton": "Brighton & Hove Albion FC",
    "West Ham": "West Ham United FC",
    "Crystal Palace": "Crystal Palace FC",
    "Nottm Forest": "Nottingham Forest FC",
    "Leicester": "Leicester City FC",
    
    # La Liga
    "Real Madrid": "Real Madrid CF",
    "Atletico Madrid": "Club Atlético de Madrid", 
    "Barcelona": "FC Barcelona",
    "Athletic Club": "Athletic Club",
    "Real Betis": "Real Betis Balompié",
    "Celta Vigo": "RC Celta de Vigo",
    "Rayo Vallecano": "Rayo Vallecano de Madrid",
    "Real Sociedad": "Real Sociedad de Fútbol",
    "Espanyol": "RCD Espanyol de Barcelona",
    "Las Palmas": "UD Las Palmas",
    "Valladolid": "Real Valladolid CF",
    
    # Serie A  
    "Inter": "FC Internazionale Milano",
    "AC Milan": "AC Milan",
    "Roma": "AS Roma",
    "Juventus": "Juventus FC",
    "Lazio": "SS Lazio",
    "Fiorentina": "ACF Fiorentina",
    "Bologna": "Bologna FC 1909",
    "Napoli": "SSC Napoli",
    "Atalanta": "Atalanta BC",
    "Torino": "Torino FC",
    "Udinese": "Udinese Calcio",
    "Genoa": "Genoa CFC",
    "Hellas Verona": "Hellas Verona FC",
    "Cagliari": "Cagliari Calcio",
    "Parma": "Parma Calcio 1913",
    "Lecce": "US Lecce",
    "Empoli": "Empoli FC",
    "Venezia": "Venezia FC",
    "Monza": "AC Monza",
    "Como": "Como 1907",
    
    # Bundesliga
    "Bayern Munich": "FC Bayern München",
    "Bayer Leverkusen": "Bayer 04 Leverkusen",
    "Eintracht Frankfurt": "Eintracht Frankfurt",
    "Borussia Dortmund": "Borussia Dortmund",
    "RB Leipzig": "RB Leipzig", 
    "Freiburg": "SC Freiburg",
    "Mainz": "1. FSV Mainz 05",
    "Werder Bremen": "SV Werder Bremen",
    "Stuttgart": "VfB Stuttgart",
    "Borussia M.Gladbach": "Borussia Mönchengladbach",
    "Wolfsburg": "VfL Wolfsburg",
    "Augsburg": "FC Augsburg",
    "Union Berlin": "1. FC Union Berlin",
    "St. Pauli": "FC St. Pauli 1910",
    "Hoffenheim": "TSG 1899 Hoffenheim",
    "Heidenheim": "1. FC Heidenheim 1846",
    "Holstein Kiel": "Holstein Kiel",
    "Bochum": "VfL Bochum 1848",
    
    # Ligue 1
    "PSG": "Paris Saint-Germain FC",
    "Marseille": "Olympique de Marseille", 
    "Monaco": "AS Monaco FC",
    "Nice": "OGC Nice",
    "Lille": "Lille OSC",
    "Lyon": "Olympique Lyonnais",
    "Strasbourg": "RC Strasbourg Alsace",
    "Lens": "Racing Club de Lens",
    "Brest": "Stade Brestois 29",
    "Toulouse": "Toulouse FC",
    "Auxerre": "AJ Auxerre",
    "Rennes": "Stade Rennais FC 1901", 
    "Nantes": "FC Nantes",
    "Angers": "Angers SCO",
    "Le Havre": "Le Havre AC",
    "Reims": "Stade de Reims",
    "Saint-Etienne": "AS Saint-Étienne",
    "Montpellier": "Montpellier HSC"
}

def hent_teams_data(liga_kode, sæson):
    url = f"https://understat.com/league/{liga_kode}/{sæson}"
    print(f"\n🌐 Henter data fra: {url}")
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        scripts = soup.find_all("script")
        
        # Look for both teamsData and playersData to understand structure
        teams_data = {}
        teams_info = {}
        
        for script in scripts:
            if script.string:
                # Extract teamsData (stats)
                teams_pattern = re.search(r"teamsData\s+=\s+JSON\.parse\('(.*)'\);", script.string)
                if teams_pattern:
                    json_str = teams_pattern.group(1).encode('utf-8').decode('unicode_escape')
                    teams_data = json.loads(json_str)
                
                # Extract team names mapping (look for team info)
                teams_info_pattern = re.search(r"teams\s+=\s+JSON\.parse\('(.*)'\);", script.string)
                if teams_info_pattern:
                    json_str = teams_info_pattern.group(1).encode('utf-8').decode('unicode_escape') 
                    teams_info = json.loads(json_str)
        
        # If we found team info, create proper mapping
        if teams_info:
            print(f"📊 Found team mappings: {len(teams_info)} teams")
            return teams_data, teams_info
        else:
            print("⚠️ No team name mappings found, using data as-is")
            return teams_data, {}

    except Exception as e:
        print(f"❌ Fejl ved hentning af {liga_kode}: {e}")
        return {}, {}

def process_xg_data():
    all_data = {}
    
    # Manual team ID mapping based on major teams
    TEAM_ID_MAPPING = {
        # Premier League (IDs from your data)
        "64": "Liverpool FC",
        "57": "Arsenal FC", 
        "65": "Manchester City FC",
        "66": "Manchester United FC",
        "61": "Chelsea FC",
        "73": "Tottenham Hotspur FC",
        "67": "Newcastle United FC",
        "58": "Aston Villa FC",
        "397": "Brighton & Hove Albion FC",
        "563": "West Ham United FC",
        "354": "Crystal Palace FC",
        "351": "Nottingham Forest FC",
        "1044": "AFC Bournemouth",
        "402": "Brentford FC",
        "63": "Fulham FC",
        "62": "Everton FC",
        "76": "Wolverhampton Wanderers FC",
        "338": "Leicester City FC",
        "349": "Ipswich Town FC",
        "340": "Southampton FC",
        
        # La Liga 
        "81": "FC Barcelona",
        "86": "Real Madrid CF",
        "78": "Club Atlético de Madrid",
        "449": "Athletic Club",
        "533": "Villarreal CF",
        "559": "Real Betis Balompié",
        "558": "RC Celta de Vigo",
        "367": "CA Osasuna",
        "565": "Valencia CF",
        "548": "Real Sociedad de Fútbol",
        "298": "Girona FC",
        "367": "Rayo Vallecano de Madrid",
        "278": "RCD Mallorca",
        "559": "Sevilla FC",
        "288": "Deportivo Alavés",
        "477": "RCD Espanyol de Barcelona",
        "545": "Getafe CF",
        "285": "CD Leganés",
        "275": "UD Las Palmas",
        "250": "Real Valladolid CF"
    }
    
    for liga_kode, liga_navn in LIGAER.items():
        teams_data, teams_info = hent_teams_data(liga_kode, sæson="2023")
        if not teams_data:
            continue

        for team_id, stats in teams_data.items():
            try:
                # Try to get team name from multiple sources
                team_name = None
                
                # 1. Try manual mapping first
                if team_id in TEAM_ID_MAPPING:
                    team_name = TEAM_ID_MAPPING[team_id]
                    print(f"✅ Manual mapping: {team_id} → {team_name}")
                
                # 2. Try teams_info if available
                elif teams_info and team_id in teams_info:
                    team_name = teams_info[team_id].get("title", team_id)
                    print(f"✅ Info mapping: {team_id} → {team_name}")
                
                # 3. Use custom name mapping as fallback
                elif team_id in custom_name_map:
                    team_name = custom_name_map[team_id]
                    print(f"✅ Custom mapping: {team_id} → {team_name}")
                
                # 4. Last resort - use ID as string
                else:
                    team_name = f"Team_{team_id}"
                    print(f"⚠️ Fallback mapping: {team_id} → {team_name}")
                
                matches = stats["history"]
                xG_total = sum(float(m["xG"]) for m in matches)
                xGA_total = sum(float(m["xGA"]) for m in matches)
                kampe = len(matches)

                all_data[team_name] = {
                    "liga": liga_navn,
                    "understat_id": team_id,  # Keep original ID for reference
                    "xG_total": round(xG_total, 2),
                    "xGA_total": round(xGA_total, 2),
                    "kampe": kampe,
                    "xG_avg": round(xG_total / kampe, 3) if kampe else None,
                    "xGA_avg": round(xGA_total / kampe, 3) if kampe else None,
                    "xG_diff": round((xG_total - xGA_total) / kampe, 3) if kampe else None,
                    "xG_ratio": round(xG_total / xGA_total, 3) if xGA_total else None
                }
                
            except Exception as e:
                print(f"⚠️ Fejl ved behandling af {team_id} ({liga_navn}): {e}")

    os.makedirs("data", exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(all_data, f, indent=2, ensure_ascii=False)
    print(f"\n✅ Gemte xG-data for {len(all_data)} hold i {OUT_PATH}")
    
    # Show successful mappings
    mapped_teams = [name for name in all_data.keys() if not name.startswith("Team_")]
    print(f"🎯 Successfully mapped {len(mapped_teams)} teams to real names")

if __name__ == "__main__":
    print(f"\n📅 Startet: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    process_xg_data()