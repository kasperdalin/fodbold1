import pandas as pd
import joblib
import numpy as np
from sklearn.model_selection import train_test_split
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier

print("🔧 Simple model retrain to fix feature mismatch...")

# Load existing training data
df = pd.read_csv("data/kampe_clean.csv")
df["dato"] = pd.to_datetime(df["dato"])

from featurizer import featurize
X_full, y, _ = featurize(df)

print(f"📊 Full training data: {X_full.shape}")

# Just remove the extra column that causes mismatch
# Since we need 41 features and have 42, let's remove the least important one
print("🎯 Reducing to 41 features by removing least important...")

# Remove the last added feature to get from 42 to 41
columns_to_keep = list(X_full.columns)[:-1]  # Remove last column
X_reduced = X_full[columns_to_keep].copy()

print(f"✅ Reduced training data: {X_reduced.shape}")

# Clean data
X_reduced = X_reduced.fillna(0)
X_reduced = X_reduced.replace([np.inf, -np.inf], 0)

# Convert to float32
for col in X_reduced.columns:
    X_reduced[col] = pd.to_numeric(X_reduced[col], errors='coerce')
X_reduced = X_reduced.fillna(0).astype(np.float32)

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X_reduced, y, test_size=0.2, shuffle=False, random_state=42
)

print(f"📊 Split: Train {X_train.shape}, Test {X_test.shape}")

# Train models
print("🚀 Training XGBoost...")
xgb_model = xgb.XGBClassifier(
    n_estimators=200, 
    max_depth=4,
    random_state=42,
    verbosity=0
)
xgb_model.fit(X_train, y_train)

print("🌲 Training Random Forest...")
rf_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train, y_train)

# Save
print("💾 Saving models...")
joblib.dump(xgb_model, "models/xgb_model.pkl")
joblib.dump(rf_model, "models/rf_model.pkl")

print("✅ Models retrained with 41 features!")
print("🎯 Now try: python3 betting_bot.py")