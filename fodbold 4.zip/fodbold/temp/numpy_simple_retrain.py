import pandas as pd
import joblib
import numpy as np
from sklearn.model_selection import train_test_split
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier

print("🔧 Ultra simple NumPy retrain...")

# Load training data
df = pd.read_csv("data/kampe_clean.csv")
df["dato"] = pd.to_datetime(df["dato"])

from featurizer import featurize
X_full, y, _ = featurize(df)

print(f"📊 Training data shape: {X_full.shape}")

# Convert to NumPy immediately to avoid pandas issues
X_numpy = X_full.values.astype(np.float32)
y_numpy = y.values.astype(np.int32)

# Take only first 41 columns to match prediction system
X_reduced = X_numpy[:, :41]  # Take first 41 features

print(f"✅ Reduced to: {X_reduced.shape}")

# Clean data
X_reduced = np.nan_to_num(X_reduced, nan=0.0, posinf=0.0, neginf=0.0)

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X_reduced, y_numpy, test_size=0.2, shuffle=False, random_state=42
)

print(f"📊 Split: Train {X_train.shape}, Test {X_test.shape}")

# Train XGBoost
print("🚀 Training XGBoost...")
xgb_model = xgb.XGBClassifier(
    n_estimators=200,
    max_depth=4, 
    random_state=42,
    verbosity=0
)
xgb_model.fit(X_train, y_train)

# Train Random Forest
print("🌲 Training Random Forest...")
rf_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train, y_train)

# Quick evaluation
xgb_acc = (xgb_model.predict(X_test) == y_test).mean()
rf_acc = (rf_model.predict(X_test) == y_test).mean()

print(f"\n📊 Performance:")
print(f"XGBoost: {xgb_acc:.3f}")
print(f"Random Forest: {rf_acc:.3f}")

# Save models
print("💾 Saving models...")
joblib.dump(xgb_model, "models/xgb_model.pkl")
joblib.dump(rf_model, "models/rf_model.pkl")

print("✅ Models retrained with 41 features using NumPy!")
print("🎯 Now run: python3 betting_bot.py")