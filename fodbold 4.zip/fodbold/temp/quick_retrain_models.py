import pandas as pd
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import joblib
import os
import numpy as np
from featurize_predict import featurize_kommende_kampe

print("🔧 Quick retrain with 41 features to match prediction system...")

# Get the exact feature structure from prediction system
mock_games = [{"hjemme": "Liverpool FC", "ude": "Arsenal FC", "dato": "2025-06-01T15:00:00Z"}]
X_template = featurize_kommende_kampe(mock_games)

print(f"📊 Prediction system generates: {len(X_template.columns)} features")
feature_columns = list(X_template.columns)

# Load training data
df = pd.read_csv("data/kampe_clean.csv")
df["dato"] = pd.to_datetime(df["dato"])

# Import the enhanced featurizer
from featurizer import featurize
X_full, y, _ = featurize(df)

print(f"📊 Training system generates: {len(X_full.columns)} features")

# Select only the features that match prediction system
print("🎯 Matching features between training and prediction...")
X_matched = pd.DataFrame(index=X_full.index)

for col in feature_columns:
    if col in X_full.columns:
        # Use .copy() to avoid DataFrame assignment issues
        X_matched[col] = X_full[col].copy()
        print(f"✅ Matched: {col}")
    else:
        X_matched[col] = 0  # Default value for missing features
        print(f"⚠️ Missing in training, using 0: {col}")

print(f"✅ Final training data: {X_matched.shape}")

# Ensure proper DataFrame structure
X_matched = pd.DataFrame(X_matched)

# Clean data
print("🔧 Cleaning data...")
X_matched = X_matched.fillna(0)
X_matched = X_matched.replace([np.inf, -np.inf], 0)

# Convert to numeric
for col in X_matched.columns:
    X_matched[col] = pd.to_numeric(X_matched[col], errors='coerce')

X_matched = X_matched.fillna(0).astype(np.float32)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X_matched, y, test_size=0.2, shuffle=False, random_state=42
)

print(f"📊 Train: {X_train.shape[0]}, Test: {X_test.shape[0]}")

# Train XGBoost
print("🚀 Training XGBoost...")
xgb_model = xgb.XGBClassifier(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.9,
    colsample_bytree=0.9,
    random_state=42,
    n_jobs=-1,
    verbosity=0
)
xgb_model.fit(X_train, y_train)

# Train Random Forest  
print("🌲 Training Random Forest...")
rf_model = RandomForestClassifier(
    n_estimators=300,
    max_depth=15,
    min_samples_split=5,
    class_weight="balanced", 
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train, y_train)

# Quick evaluation
xgb_acc = accuracy_score(y_test, xgb_model.predict(X_test))
rf_acc = accuracy_score(y_test, rf_model.predict(X_test))

print(f"\n📊 Quick Performance Check:")
print(f"XGBoost: {xgb_acc:.3f}")
print(f"Random Forest: {rf_acc:.3f}")

# Save models
print("\n💾 Saving models...")
os.makedirs("models", exist_ok=True)
joblib.dump(xgb_model, "models/xgb_model.pkl")
joblib.dump(rf_model, "models/rf_model.pkl")

print("✅ Models retrained and saved!")
print(f"🎯 Now using {len(feature_columns)} features (matching prediction system)")