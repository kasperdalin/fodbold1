import pandas as pd
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
import joblib
import os
import numpy as np
from datetime import datetime

from featurizer import indlaes_kampe, featurize

print("🚀 Starting ensemble model training...")

# === 1. Læs og featurize ===
# FIXED: Use fresh data from featurizer instead of cached CSV
print("🔄 Loading fresh data with featurizer...")
df = indlaes_kampe("data/kampe.json")  # Load fresh from JSON
X, y, _ = featurize(df)

print(f"✅ Generated {len(X.columns)} features for training")
print(f"📊 Dataset: {X.shape[0]} samples, {X.shape[1]} features")
print(f"🎯 Target distribution: {y.value_counts().to_dict()}")

# === 2. ROBUST DATA CLEANING ===
print("🔧 Robust data cleaning...")

# Convert to pure NumPy to avoid pandas issues
print("   Converting to NumPy arrays...")

# Clean X data
X_clean = X.copy()
X_clean = X_clean.fillna(0)
X_clean = X_clean.replace([np.inf, -np.inf], 0)

# Convert to numeric explicitly
for col in X_clean.columns:
    try:
        X_clean[col] = pd.to_numeric(X_clean[col].astype(str), errors='coerce')
    except:
        X_clean[col] = 0

X_clean = X_clean.fillna(0)

# Convert to NumPy array
X_numpy = X_clean.values.astype(np.float32)
y_numpy = y.values.astype(np.int32)

# Store feature names for later
feature_names = list(X_clean.columns)

print(f"✅ Data converted to NumPy:")
print(f"   X shape: {X_numpy.shape}, dtype: {X_numpy.dtype}")
print(f"   y shape: {y_numpy.shape}, dtype: {y_numpy.dtype}")
print(f"   Features: {len(feature_names)}")

# === 3. Split data tidsmæssigt ===
X_train, X_test, y_train, y_test = train_test_split(
    X_numpy, y_numpy, test_size=0.2, shuffle=False, random_state=42
)

print(f"📊 Train: {X_train.shape[0]}, Test: {X_test.shape[0]}")

# === 4. Træn XGBoost ===
print("🚀 Training XGBoost...")
try:
    xgb_model = xgb.XGBClassifier(
        n_estimators=300,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42,
        n_jobs=-1,
        verbosity=0
    )
    xgb_model.fit(X_train, y_train)
    print("✅ XGBoost training completed")
    
except Exception as e:
    print(f"❌ XGBoost error: {e}")
    print("🔄 Trying simpler XGBoost config...")
    
    xgb_model = xgb.XGBClassifier(
        n_estimators=200,
        max_depth=4,
        random_state=42
    )
    xgb_model.fit(X_train, y_train)
    print("✅ XGBoost training completed (fallback config)")

# === 5. Træn Random Forest ===
print("🌲 Training Random Forest...")
rf_model = RandomForestClassifier(
    n_estimators=300,
    max_depth=15,
    min_samples_split=5,
    class_weight="balanced",
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train, y_train)
print("✅ Random Forest training completed")

# === 6. Evaluering ===
print("🔮 Evaluating models...")

try:
    # Predictions
    xgb_pred = xgb_model.predict(X_test)
    rf_pred = rf_model.predict(X_test)
    
    xgb_probs = xgb_model.predict_proba(X_test)
    rf_probs = rf_model.predict_proba(X_test)
    
    # Ensemble
    ensemble_probs = (xgb_probs + rf_probs) / 2
    ensemble_pred = ensemble_probs.argmax(axis=1)
    
    # Accuracies
    acc_xgb = accuracy_score(y_test, xgb_pred)
    acc_rf = accuracy_score(y_test, rf_pred)
    acc_ens = accuracy_score(y_test, ensemble_pred)
    
    # AUC scores
    try:
        auc_xgb = roc_auc_score(y_test, xgb_probs, multi_class='ovr')
        auc_rf = roc_auc_score(y_test, rf_probs, multi_class='ovr')
        auc_ens = roc_auc_score(y_test, ensemble_probs, multi_class='ovr')
    except:
        auc_xgb = auc_rf = auc_ens = 0.0
    
    print("\n📊 MODEL PERFORMANCE:")
    print(f"XGBoost      → Accuracy: {acc_xgb:.3f} | AUC: {auc_xgb:.3f}")
    print(f"RandomForest → Accuracy: {acc_rf:.3f} | AUC: {auc_rf:.3f}")
    print(f"Ensemble     ✅ Accuracy: {acc_ens:.3f} | AUC: {auc_ens:.3f}")
    
    # === 7. Log metrics ===
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_path = "ensemble_metrics.csv"
    write_header = not os.path.isfile(log_path)
    
    log_data = pd.DataFrame([
        {"timestamp": timestamp, "model": "xgboost", "accuracy": round(acc_xgb, 3), "auc": round(auc_xgb, 3)},
        {"timestamp": timestamp, "model": "random_forest", "accuracy": round(acc_rf, 3), "auc": round(auc_rf, 3)},
        {"timestamp": timestamp, "model": "ensemble", "accuracy": round(acc_ens, 3), "auc": round(auc_ens, 3)},
    ])
    
    log_data.to_csv(log_path, mode="a", index=False, header=write_header)
    print("📝 Metrics logged to ensemble_metrics.csv")
    
except Exception as e:
    print(f"❌ Evaluation error: {e}")
    print("🔄 Continuing with model saving...")

# === 8. Gem modeller ===
print("\n💾 Saving models...")
os.makedirs("models", exist_ok=True)

try:
    joblib.dump(xgb_model, "models/xgb_model.pkl")
    print("✅ XGBoost model saved")
except Exception as e:
    print(f"❌ XGBoost save error: {e}")

try:
    joblib.dump(rf_model, "models/rf_model.pkl")
    print("✅ Random Forest model saved")
except Exception as e:
    print(f"❌ Random Forest save error: {e}")

# === 9. Feature importance ===
try:
    if hasattr(xgb_model, 'feature_importances_'):
        print("\n🔝 TOP 10 MOST IMPORTANT FEATURES:")
        
        feature_importance = pd.DataFrame({
            'feature': feature_names,
            'importance': xgb_model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        for i, (_, row) in enumerate(feature_importance.head(10).iterrows()):
            print(f"  {i+1:2d}. {row['feature']:30s} ({row['importance']:.4f})")
except Exception as e:
    print(f"⚠️ Feature importance error: {e}")

print("\n🎉 TRAINING COMPLETED!")
print(f"✅ Models saved to models/ directory")
print(f"📊 Total features used: {len(feature_names)}")