import json
from datetime import datetime, timedelta

def create_mock_upcoming_games():
    """Create mock upcoming games for testing"""
    
    future_date = (datetime.now() + timedelta(days=2)).isoformat() + "Z"
    
    mock_games = [
        {
            "area": {"id": 2072, "name": "England"},
            "competition": {"id": 2021, "name": "Premier League"},
            "id": 999001,
            "utcDate": future_date,
            "status": "SCHEDULED",
            "homeTeam": {"id": 64, "name": "Liverpool FC"},
            "awayTeam": {"id": 57, "name": "Arsenal FC"},
            "score": {"winner": None, "fullTime": {"home": None, "away": None}}
        },
        {
            "area": {"id": 2072, "name": "England"},
            "competition": {"id": 2021, "name": "Premier League"},
            "id": 999002,
            "utcDate": future_date,
            "status": "SCHEDULED",
            "homeTeam": {"id": 65, "name": "Manchester City FC"},
            "awayTeam": {"id": 61, "name": "Chelsea FC"},
            "score": {"winner": None, "fullTime": {"home": None, "away": None}}
        },
        {
            "area": {"id": 2088, "name": "Spain"},
            "competition": {"id": 2014, "name": "La Liga"},
            "id": 999003,
            "utcDate": future_date,
            "status": "SCHEDULED",
            "homeTeam": {"id": 81, "name": "FC Barcelona"},
            "awayTeam": {"id": 86, "name": "Real Madrid CF"},
            "score": {"winner": None, "fullTime": {"home": None, "away": None}}
        }
    ]
    
    # Load existing games and add mock games
    try:
        with open("data/kampe.json", "r", encoding="utf-8") as f:
            existing_games = json.load(f)
    except:
        existing_games = []
    
    # Remove any existing mock games to avoid duplicates
    existing_games = [g for g in existing_games if g.get("id", 0) < 999000]
    
    # Add mock games
    all_games = existing_games + mock_games
    
    # Save back
    with open("data/kampe.json", "w", encoding="utf-8") as f:
        json.dump(all_games, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Added {len(mock_games)} mock upcoming games to kampe.json")
    print(f"📊 Total games now: {len(all_games)}")
    
    for game in mock_games:
        print(f"   🆚 {game['homeTeam']['name']} vs {game['awayTeam']['name']}")

if __name__ == "__main__":
    create_mock_upcoming_games()