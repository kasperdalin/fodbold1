import requests
import pandas as pd
import time
from io import StringIO
import json
from datetime import datetime, timedelta

teams = [
    "Barcelona", "RealMadrid", "Atletico", "Bilbao", "Villarreal", "Betis", "Celta", "Osasuna", "Valencia", "Sociedad",
    "Girona", "RayoVallecano", "Mallorca", "Sevilla", "Alaves", "Espanyol", "Getafe", "Leganes", "LasPalmas", "Valladolid",
    "Liverpool", "Arsenal", "ManCity", "Newcastle", "Chelsea", "AstonVilla", "CrystalPalace", "Brentford", "Bournemouth", "Forest",
    "Brighton", "ManUnited", "Tottenham", "Everton", "Fulham", "WestHam", "Wolves", "Leicester", "Ipswich", "Southampton",
    "Inter", "Atalanta", "Napoli", "Roma", "Juventus", "Milan", "Lazio", "Bologna", "Fiorentina", "Torino",
    "Como", "Genoa", "Udinese", "Cagliari", "Verona", "Parma", "Empoli", "Venezia", "Lecce", "Monza",
    "ParisSG", "Monaco", "Lille", "Marseille", "Lyon", "Strasbourg", "Nice", "Brest", "Lens", "Rennes",
    "Toulouse", "Auxerre", "Reims", "Nantes", "Angers", "LeHavre", "Saint-Etienne", "Montpellier",
    "Bayern", "Leverkusen", "Dortmund", "Frankfurt", "RBLeipzig", "Stuttgart", "Mainz", "Freiburg", "Werder",
    "Gladbach", "Wolfsburg", "Augsburg", "Hoffenheim", "UnionBerlin", "StPauli", "Heidenheim", "Holstein", "Bochum"
]

today = datetime.today()
dates_to_check = {
    "elo_today": today,
    "elo_7d": today - timedelta(days=7),
    "elo_14d": today - timedelta(days=14),
    "elo_30d": today - timedelta(days=30),
}

elo_features = {}

for team in teams:
    print(f"Henter Elo-historik for {team}...")
    url = f"http://api.clubelo.com/{team}"
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        df = pd.read_csv(StringIO(response.text))
        df['To'] = pd.to_datetime(df['To'])

        team_elos = {}
        for label, date in dates_to_check.items():
            closest = df.iloc[(df['To'] - date).abs().argsort()[:1]]
            team_elos[label] = round(float(closest["Elo"].values[0]), 2)

        elo_features[team] = team_elos

    except Exception as e:
        print(f"⚠️ Fejl ved {team}: {e}")
        elo_features[team] = {k: None for k in dates_to_check.keys()}

    time.sleep(1.5)

# Gem som JSON
with open("elo_historik.json", "w") as f:
    json.dump(elo_features, f, indent=2)

print("✅ Elo-historik gemt i elo_historik.json")
