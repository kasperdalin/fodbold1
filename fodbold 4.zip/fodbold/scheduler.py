import schedule
import time
import subprocess
from datetime import datetime

# Plan: Kør disse dagligt
# 1. Hent nye kampe
# 2. Opdater features
# 3. Træn model
# 4. Forudsig og find value bets

def job():
    print("\n[START] Kører fuld automatisering", datetime.now())

    print("\n▶️ Henter kampdata...")
    subprocess.run(["python3", "data_fetcher.py"])

    print("\n▶️ Opdaterer features...")
    subprocess.run(["python3", "featurizer.py"])

    print("\n▶️ Træner model...")
    subprocess.run(["python3", "predictor.py"])

    print("\n▶️ Finder value bets...")
    subprocess.run(["python3", "betting_bot.py"])

    print("\n✅ [SLUT] Kørsel færdig", datetime.now())

# Planlæg job dagligt kl. 10
schedule.every().day.at("10:00").do(job)

print("Automatiseret betting-bot scheduler kører... (Ctrl+C for at stoppe)")
while True:
    schedule.run_pending()
    time.sleep(60)
