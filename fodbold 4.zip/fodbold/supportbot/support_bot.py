import discord
import os
from discord.ext import commands
from discord import app_commands

# Token til supportbot hentes fra miljøvariabel
TOKEN = os.getenv("SUPPORTBOT_TOKEN", "MTM3NDAwMDgzMzgyMTQxMzM5OQ.GhWMUy.UcBY8qjhH1kMzft2pDLT8G5tFMpIaQIP8VH2NU")

intents = discord.Intents.default()
intents.message_content = True

# === UI-KOMPONENT: Dropdown-menu ===
class HelpSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Hvordan bruger jeg botten?", value="brug"),
            discord.SelectOption(label="Hvad betyder Value Bet?", value="value"),
            discord.SelectOption(label="Hvordan kontakter jeg support?", value="support"),
        ]
        super().__init__(placeholder="Vælg en hjælpemulighed...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "brug":
            await interaction.response.send_message("➡️ For at bruge botten, skriv `!valuebets` eller `!odds`.")
        elif self.values[0] == "value":
            await interaction.response.send_message("💡 Et value bet betyder, at vores model mener oddsene er højere end sandsynligheden.")
        elif self.values[0] == "support":
            await interaction.response.send_message("📩 Du kan kontakte support ved at skrive i support-kanalen eller tagge en admin.")

class HelpView(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.add_item(HelpSelect())

# === Supportbot setup ===
support_bot = commands.Bot(command_prefix="!", intents=intents)
tree = support_bot.tree

# === Slash command: /help ===
@tree.command(name="help", description="Få hjælp via dropdown-menu")
async def help_slash(interaction: discord.Interaction):
    await interaction.response.send_message("📋 Vælg en hjælpemulighed nedenfor:", view=HelpView(), ephemeral=True)

# === Events ===
@support_bot.event
async def on_ready():
    synced = await tree.sync()
    activity = discord.Activity(type=discord.ActivityType.watching, name="tickets | Use /help")
    await support_bot.change_presence(status=discord.Status.online, activity=activity)

    print(f"✅ Supportbotten er logget ind som {support_bot.user}")
    print(f"📌 Synced {len(synced)} slash-kommando(er): {[cmd.name for cmd in synced]}")

@support_bot.event
async def on_message(message):
    if message.author == support_bot.user:
        return

    if message.content.lower() == "!hjælp":
        await message.channel.send("Hej! Jeg er supportbotten. Skriv `!valuebets` for betting tips eller `!odds` for odds.")
    elif message.content.lower() == "!ping":
        await message.channel.send("Pong! Supportbotten er klar.")

# === Bruges til at importere botten fra discord_bot.py ===
client = support_bot

# === Hvis scriptet køres direkte ===
if __name__ == "__main__":
    support_bot.run(TOKEN)
