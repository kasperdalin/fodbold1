import discord
import os
import asyncio
import threading
from betting_bot import discord_odds_tekst, hent_odds_tekst
from supportbot.support_bot import support_bot  # ✅ IMPORTÉR BOT-OBJEKTET

# === Tokens ===
BETTING_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "MTM3MzMyMjc0NjE4MzgxMTI5Mw.Glrwt9.obQWHfuucGVqAGmBNcibALGgnNs5TyuIRinyjk")
SUPPORT_TOKEN = os.getenv("SUPPORTBOT_TOKEN", "MTM3NDAwMDgzMzgyMTQxMzM5OQ.GhWMUy.UcBY8qjhH1kMzft2pDLT8G5tFMpIaQIP8VH2NU")
CHANNEL_ID = int(os.getenv("DISCORD_CHANNEL_ID", 1367188719584415897))

# === Betting Bot ===
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f"✅ Bettingbotten er logget ind som {client.user}")
    kanal = client.get_channel(CHANNEL_ID)

    if kanal:
        try:
            besked = discord_odds_tekst()
            if besked:
                await kanal.send("📢 **Auto Value Bets ved opstart:**\n" + besked[:2000])
        except Exception as e:
            print(f"[FEJL ved Discord-feed]: {e}")
    else:
        print("[FEJL] Kunne ikke finde kanal")

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.lower() == "!valuebets":
        await message.channel.send("🔄 Henter dagens value bets...")
        try:
            besked = discord_odds_tekst()
            await message.channel.send(besked[:2000])
        except Exception as e:
            await message.channel.send(f"⚠️ Fejl ved hentning: {e}")

    elif message.content.lower() == "!odds":
        await message.channel.send("📊 Henter odds for kommende kampe...")
        try:
            odds_besked = hent_odds_tekst()
            await message.channel.send(odds_besked[:2000])
        except Exception as e:
            await message.channel.send(f"⚠️ Fejl ved hentning: {e}")

# === Kør begge bots ===
def start_supportbot():
    support_bot.run(SUPPORT_TOKEN)

if __name__ == "__main__":
    threading.Thread(target=start_supportbot).start()
    client.run(BETTING_TOKEN)
