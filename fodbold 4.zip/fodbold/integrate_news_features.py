"""
INTEGRATE NEWS PSYCHOLOGY FEATURES INTO BETTING SYSTEM
Add 11 new psychology features to enhance predictions
"""

from news_api_integrator import FootballNewsAnalyzer
import pandas as pd

class NewsFeatureIntegrator:
    
    def __init__(self, news_api_key):
        self.news_analyzer = FootballNewsAnalyzer(news_api_key)
    
    def add_psychology_features(self, df_features, kampe):
        """
        Add psychology features to existing feature DataFrame
        """
        print("🧠 Adding psychology features...")
        
        # Get unique teams from matches
        teams_to_analyze = set()
        for kamp in kampe:
            teams_to_analyze.add(kamp['hjemme'])
            teams_to_analyze.add(kamp['ude'])
        
        print(f"📊 Analyzing psychology for {len(teams_to_analyze)} teams...")
        
        # Get psychology data for all teams
        team_psychology = {}
        for team in teams_to_analyze:
            psychology = self.news_analyzer.get_team_psychology_features(team, days_back=7)
            team_psychology[team] = psychology
        
        # Add psychology features to DataFrame
        psychology_features = []
        
        for i, kamp in enumerate(kampe):
            home_team = kamp['hjemme']
            away_team = kamp['ude']
            
            home_psych = team_psychology.get(home_team, self._default_psychology())
            away_psych = team_psychology.get(away_team, self._default_psychology())
            
            # Create differential features
            match_psychology = {
                # Sentiment differentials
                'sentiment_differential': home_psych['news_sentiment_score'] - away_psych['news_sentiment_score'],
                'home_sentiment': home_psych['news_sentiment_score'],
                'away_sentiment': away_psych['news_sentiment_score'],
                
                # Manager pressure
                'manager_pressure_differential': away_psych['manager_pressure_level'] - home_psych['manager_pressure_level'],
                'home_manager_pressure': home_psych['manager_pressure_level'],
                'away_manager_pressure': away_psych['manager_pressure_level'],
                
                # Controversy factors
                'controversy_differential': away_psych['controversy_level'] - home_psych['controversy_level'],
                'total_controversy': home_psych['controversy_level'] + away_psych['controversy_level'],
                
                # Injury concerns
                'injury_concern_differential': away_psych['injury_concern_level'] - home_psych['injury_concern_level'],
                
                # News activity (media attention)
                'news_attention_differential': home_psych['news_activity'] - away_psych['news_activity'],
                
                # Confidence in psychology data
                'psychology_confidence': (home_psych['news_confidence'] + away_psych['news_confidence']) / 2
            }
            
            psychology_features.append(match_psychology)
        
        # Convert to DataFrame
        psychology_df = pd.DataFrame(psychology_features)
        
        # Combine with existing features
        enhanced_df = pd.concat([df_features.reset_index(drop=True), psychology_df], axis=1)
        
        print(f"✅ Added {len(psychology_df.columns)} psychology features")
        print(f"📊 Total features now: {len(enhanced_df.columns)}")
        
        return enhanced_df
    
    def _default_psychology(self):
        """Default psychology data when team analysis fails"""
        return {
            'news_sentiment_score': 0.0,
            'news_confidence': 0.0,
            'manager_pressure_level': 0.0,
            'controversy_level': 0.0,
            'injury_concern_level': 0.0,
            'news_activity': 0.0
        }