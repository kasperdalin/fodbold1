import json
import pandas as pd
import joblib
import os
import csv
import numpy as np
from datetime import datetime, datetime as dt
from combine_odds import hent_kombinerede_odds
from featurize_predict import featurize_kommende_kampe

XGB_PATH = "models/xgb_model.pkl"
RF_PATH = "models/rf_model.pkl"
KAMPE_PATH = "data/kampe.json"
LOG_PATH = "data/betting_log.csv"

# 🆕 ADD THIS MOCK FUNCTION HERE (after imports, before other functions)
def hent_kombinerede_odds_mock():
    """Use mock odds data instead of live API during off-season"""
    import json
    
    # Load mock odds data
    try:
        with open("data/odds_data.json", "r", encoding="utf-8") as f:
            odds_data = json.load(f)
    except:
        odds_data = []
    
    # Convert to expected format
    odds_api_data = {}
    for game in odds_data:
        key = f"{game['home_team']} vs {game['away_team']}"
        odds_api_data[key] = game["odds"]
    
    # Load Betfair data
    try:
        with open("data/betfair_odds.json", "r", encoding="utf-8") as f:
            betfair_data = json.load(f)
    except:
        betfair_data = []
    
    # Matcher function
    def match_kampe(hjemme, ude, odds_api_data, betfair_data):
        from rapidfuzz import fuzz
        
        kamp_id = f"{hjemme} vs {ude}"
        odds_api_odds = odds_api_data.get(kamp_id, {"1": 2.0, "X": 3.5, "2": 3.0})
        
        # Try fuzzy matching for better team matching
        if kamp_id not in odds_api_data:
            for api_key, api_odds in odds_api_data.items():
                api_home, api_away = api_key.split(" vs ")
                home_score = fuzz.ratio(hjemme.lower(), api_home.lower())
                away_score = fuzz.ratio(ude.lower(), api_away.lower())
                
                if home_score > 80 and away_score > 80:
                    odds_api_odds = api_odds
                    break
        
        return {
            "betfair": None,
            "bookmakers": odds_api_odds, 
            "average": odds_api_odds
        }
    
    return odds_api_data, betfair_data, match_kampe

# EXISTING FUNCTIONS REMAIN THE SAME
def hent_naeste_kampe():
    if not os.path.exists(KAMPE_PATH):
        print("[FEJL] Kan ikke finde kampe.json")
        return []

    with open(KAMPE_PATH, "r", encoding="utf-8") as f:
        kampe = json.load(f)

    fremtidige = []
    for kamp in kampe:
        if kamp["status"] != "SCHEDULED":
            continue

        hjem = kamp["homeTeam"]["name"]
        ude = kamp["awayTeam"]["name"]
        dato = kamp["utcDate"]

        fremtidige.append({
            "hjemme": hjem,
            "ude": ude,
            "dato": dato
        })

    return fremtidige

def predict_kampe():
    if not (os.path.exists(XGB_PATH) and os.path.exists(RF_PATH)):
        print("[FEJL] Mangler en eller begge modeller.")
        return []

    xgb_model = joblib.load(XGB_PATH)
    rf_model = joblib.load(RF_PATH)
    kampe = hent_naeste_kampe()
    
    if not kampe:
        print("📭 Ingen kommende kampe fundet.")
        return []
    
    # 🆕 CHANGE THIS LINE - USE MOCK FUNCTION INSTEAD
    odds_api_data, betfair_data, matcher = hent_kombinerede_odds_mock()

    predictions = []
    X = featurize_kommende_kampe(kampe)
    
    # 🆕 FIX DATA TYPES FOR XGBOOST - FINAL VERSION
    print("🔧 Fixing data types for XGBoost...")
    X = X.fillna(0)  # Fill NaN values
    X = X.replace([np.inf, -np.inf], 0)  # Replace infinite values
    
    # Convert all columns to float32 - FIXED VERSION
    for col in X.columns:
        try:
            X[col] = pd.to_numeric(X[col], errors='coerce')
        except (TypeError, ValueError):
            # If column is already numeric array or conversion fails, skip
            pass
    
    X = X.fillna(0).astype(np.float32)
    
    print(f"✅ Data cleaned: {X.shape}, dtypes: {X.dtypes.nunique()} unique types")

    for i, kamp in enumerate(kampe):
        hjem = kamp["hjemme"]
        ude = kamp["ude"]

        print(f"\nTjekker kamp: {hjem} vs {ude}")

        try:
            # Convert to numpy array for XGBoost - FIXED!
            X_row = X.iloc[[i]].values.astype(np.float32)
            
            xgb_probs = xgb_model.predict_proba(X_row)[0]
            rf_probs = rf_model.predict_proba(X_row)[0]
            avg_probs = (xgb_probs + rf_probs) / 2
            classes = xgb_model.classes_

            prediction = classes[avg_probs.argmax()]
            confidence = max(avg_probs)

            print(f"   🎯 Prediction: {prediction}, Confidence: {confidence:.3f}")

            kamp_id = f"{hjem} vs {ude}"
            combined_odds = matcher(hjem, ude, odds_api_data, betfair_data)
            odds = combined_odds["average"]

            if prediction == 1:
                implied = 1 / odds["1"]
            elif prediction == 0:
                implied = 1 / odds["X"]
            else:
                implied = 1 / odds["2"]

            value_bet = prediction if confidence > implied else "Ingen"
            
            print(f"   💰 Implied prob: {implied:.3f}, Value bet: {value_bet}")

            resultat = {
                "kamp": kamp_id,
                "dato": kamp["dato"],
                "prediction": prediction,
                "sandsynlighed": round(confidence, 3),
                "value_bet": value_bet,
                "odds": odds,
                "source": "ensemble"
            }
            predictions.append(resultat)
            
        except Exception as e:
            print(f"❌ Error predicting {hjem} vs {ude}: {e}")
            continue

    return predictions

# REST OF THE FILE REMAINS EXACTLY THE SAME
def log_til_csv(resultater):
    os.makedirs("data", exist_ok=True)
    felt_navne = ["timestamp", "kamp", "dato", "prediction", "sandsynlighed", "value_bet", "odds_1", "odds_X", "odds_2", "source"]
    ny_log = []

    for kamp in resultater:
        ny_log.append({
            "timestamp": dt.utcnow().isoformat(),
            "kamp": kamp["kamp"],
            "dato": kamp["dato"],
            "prediction": kamp["prediction"],
            "sandsynlighed": kamp["sandsynlighed"],
            "value_bet": kamp["value_bet"],
            "odds_1": kamp["odds"].get("1", None),
            "odds_X": kamp["odds"].get("X", None),
            "odds_2": kamp["odds"].get("2", None),
            "source": kamp["source"]
        })

    fil_eksisterer = os.path.exists(LOG_PATH)
    with open(LOG_PATH, "a", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=felt_navne)
        if not fil_eksisterer:
            writer.writeheader()
        writer.writerows(ny_log)

if __name__ == "__main__":
    forudsigelser = predict_kampe()
    if forudsigelser:
        log_til_csv(forudsigelser)
        for kamp in forudsigelser:
            print(f"\nKamp: {kamp['kamp']} ({kamp['dato']})")
            print(f"Forudsigelse: {kamp['prediction']} med {kamp['sandsynlighed']*100:.1f}% sikkerhed")
            if kamp['value_bet'] != "Ingen":
                odds_key = {1: "1", 0: "X", 2: "2"}.get(kamp['value_bet'], "ukendt")
                odds_value = kamp['odds'].get(odds_key, 'ukendt')
                print(f"➡️ VALUE BET fundet på udfald: {kamp['value_bet']} ✅ (odds: {odds_value})")
            else:
                print("Ingen value bet i denne kamp")

def discord_odds_tekst():
    forudsigelser = predict_kampe()
    if not forudsigelser:
        return "⚠️ Ingen value bets fundet i dag."

    linjer = ["📊 **Dagens Value Bets:**\n"]
    for kamp in forudsigelser:
        linjer.append(f"**{kamp['kamp']}** ({kamp['dato']})")
        linjer.append(f"🔮 Forudsigelse: `{kamp['prediction']}` med `{kamp['sandsynlighed']*100:.1f}%`")

        if kamp['value_bet'] != "Ingen":
            odds_key = {1: "1", 0: "X", 2: "2"}.get(kamp['value_bet'], "ukendt")
            odds_value = kamp['odds'].get(odds_key, "ukendt")
            linjer.append(f"💸 Value Bet: `{kamp['value_bet']}` ✅ (odds: {odds_value})")
        else:
            linjer.append("📉 Ingen value bet.")
        linjer.append("")

    return "\n".join(linjer[:40])

def hent_odds_tekst():
    odds_api_data, betfair_data, matcher = hent_kombinerede_odds_mock()
    kampe = hent_naeste_kampe()

    linjer = ["📊 **Kommende kampe – gennemsnitsodds:**\n"]
    for kamp in kampe[:10]:
        hjem = kamp["hjemme"]
        ude = kamp["ude"]
        odds = matcher(hjem, ude, odds_api_data, betfair_data)["average"]

        linjer.append(f"**{hjem} vs {ude}**")
        linjer.append(f"1: {odds['1']} | X: {odds['X']} | 2: {odds['2']}")
        linjer.append("")

    return "\n".join(linjer)