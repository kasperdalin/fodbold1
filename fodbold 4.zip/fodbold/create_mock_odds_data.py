import json
from datetime import datetime, timedelta

def create_mock_odds():
    """Create realistic mock odds data for testing"""
    
    # Sample upcoming games (simulate start of new season)
    future_date = datetime.now() + timedelta(days=3)
    future_date_str = future_date.isoformat() + "Z"
    
    mock_games = [
        {
            "league": "soccer_epl",
            "home_team": "Liverpool FC",
            "away_team": "Arsenal FC",
            "commence_time": future_date_str,
            "bookmakers": [
                {
                    "title": "Bet365",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 2.10, "X": 3.40, "2": 3.20}
                },
                {
                    "title": "William Hill", 
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 2.05, "X": 3.50, "2": 3.30}
                }
            ],
            "odds": {"1": 2.075, "X": 3.45, "2": 3.25}
        },
        {
            "league": "soccer_epl",
            "home_team": "Manchester City FC",
            "away_team": "Chelsea FC", 
            "commence_time": future_date_str,
            "bookmakers": [
                {
                    "title": "Bet365",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 1.80, "X": 3.60, "2": 4.20}
                },
                {
                    "title": "William Hill",
                    "last_update": datetime.now().isoformat() + "Z", 
                    "odds": {"1": 1.85, "X": 3.70, "2": 4.00}
                }
            ],
            "odds": {"1": 1.825, "X": 3.65, "2": 4.10}
        },
        {
            "league": "soccer_spain_la_liga",
            "home_team": "FC Barcelona",
            "away_team": "Real Madrid CF",
            "commence_time": future_date_str,
            "bookmakers": [
                {
                    "title": "Bet365",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 2.30, "X": 3.20, "2": 2.90}
                },
                {
                    "title": "William Hill",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 2.25, "X": 3.30, "2": 2.95}
                }
            ],
            "odds": {"1": 2.275, "X": 3.25, "2": 2.925}
        },
        {
            "league": "soccer_germany_bundesliga", 
            "home_team": "FC Bayern München",
            "away_team": "Borussia Dortmund",
            "commence_time": future_date_str,
            "bookmakers": [
                {
                    "title": "Bet365",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 1.70, "X": 3.80, "2": 4.50}
                },
                {
                    "title": "William Hill",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 1.75, "X": 3.90, "2": 4.30}
                }
            ],
            "odds": {"1": 1.725, "X": 3.85, "2": 4.40}
        },
        {
            "league": "soccer_italy_serie_a",
            "home_team": "FC Internazionale Milano", 
            "away_team": "SSC Napoli",
            "commence_time": future_date_str,
            "bookmakers": [
                {
                    "title": "Bet365",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 2.00, "X": 3.40, "2": 3.60}
                },
                {
                    "title": "William Hill",
                    "last_update": datetime.now().isoformat() + "Z",
                    "odds": {"1": 1.95, "X": 3.50, "2": 3.70}
                }
            ],
            "odds": {"1": 1.975, "X": 3.45, "2": 3.65}
        }
    ]
    
    # Save mock data
    with open("data/odds_data.json", "w", encoding="utf-8") as f:
        json.dump(mock_games, f, indent=2)
    
    print(f"✅ Created mock odds data with {len(mock_games)} games")
    print("📊 Sample game:")
    print(json.dumps(mock_games[0], indent=2))
    
    return mock_games

if __name__ == "__main__":
    create_mock_odds()