import requests
import json
import time
from datetime import datetime

API_KEY = "3ea7581f7fa34b1fbb5d58ffc46a5821"  # <-- Erstat med din egen Football-Data.org API-nøgle
BASE_URL = "https://api.football-data.org/v4"
HEADERS = {"X-Auth-Token": API_KEY}

# Liga-koder: PL (England), BL1 (Tyskland), PD (Spanien), SA (Italien), FL1 (Frankrig)
LIGAER = ["PL", "BL1", "PD", "SA", "FL1"]


def hent_kampe(liga_kode, season=None):
    if season is None:
        today = datetime.today()
        year = today.year
        month = today.month
        # Hvis det er før juli, bruger vi forrige års sæson (2023 fx = 2022/23)
        season = year - 1 if month < 7 else year

    url = f"{BASE_URL}/competitions/{liga_kode}/matches?season={season}"
    response = requests.get(url, headers=HEADERS)

    if response.status_code == 200:
        print(f"[OK] Hentede kampe for {liga_kode} ({season})")
        return response.json().get("matches", [])
    else:
        print(f"[FEJL] Kunne ikke hente {liga_kode}: {response.status_code}")
        return []


def hent_alle_kampe():
    alle_kampe = []
    for liga in LIGAER:
        kampe = hent_kampe(liga)
        alle_kampe.extend(kampe)
        time.sleep(1)  # undgå rate limit
    return alle_kampe


if __name__ == "__main__":
    kampe = hent_alle_kampe()
    with open("data/kampe.json", "w", encoding="utf-8") as f:
        json.dump(kampe, f, indent=2, ensure_ascii=False)
    print(f"Gemte {len(kampe)} kampe i data/kampe.json")