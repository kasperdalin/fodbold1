import pandas as pd
import xgboost as xgb
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score
from datetime import datetime
import os

from featurizer import featurize

# 1. Læs kampdata
df = pd.read_csv("data/kampe_clean.csv")
df["dato"] = pd.to_datetime(df["dato"])  # <--- DENNE LINJE FIKSER DIN FEJL

# 2. Featurize
X, y, _ = featurize(df)

# 3. Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

# 4. Træn XGBoost
model = xgb.XGBClassifier(
    n_estimators=200,
    learning_rate=0.05,
    max_depth=5,
    subsample=0.9,
    colsample_bytree=0.9,
    eval_metric="mlogloss"
)

model.fit(X_train, y_train)

# 5. Evaluer
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)

acc = accuracy_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob, multi_class='ovr')

print(f"✅ Accuracy: {acc:.3f}")
print(f"✅ AUC: {auc:.3f}")

# 6. Gem model
joblib.dump(model, "models/xgb_model.pkl")
print("✅ Model gemt som models/xgb_model.pkl")

# 7. Log metrics med dato og tid
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

metrics_df = pd.DataFrame([{
    "timestamp": timestamp,
    "accuracy": round(acc, 3),
    "auc": round(auc, 3)
}])

log_path = "model_metrics.csv"
write_header = not os.path.isfile(log_path)
metrics_df.to_csv(log_path, mode="a", index=False, header=write_header)

print("✅ Metrics logget i model_metrics.csv")
