import json
import pandas as pd
import os
from sklearn.preprocessing import LabelEncoder
import numpy as np

def compute_bookmaker_spread(row):
    try:
        odds = [row['home_odds'], row['draw_odds'], row['away_odds']]
        return np.std(odds)
    except:
        return None

def indlaes_kampe(sti="data/kampe.json"):
    if not os.path.exists(sti):
        print("[FEJL] Kan ikke finde kampdata")
        return pd.DataFrame()

    with open(sti, "r", encoding="utf-8") as f:
        kampe = json.load(f)

    records = []
    for kamp in kampe:
        if kamp["status"] != "FINISHED":
            continue

        home = kamp["homeTeam"]["name"]
        away = kamp["awayTeam"]["name"]
        date = kamp["utcDate"]

        full_time = kamp["score"].get("fullTime", {})
        home_goals = full_time.get("home", 0)
        away_goals = full_time.get("away", 0)

        if home_goals > away_goals:
            result = 1
        elif home_goals < away_goals:
            result = -1
        else:
            result = 0

        records.append({
            "dato": date,
            "hjemme": home,
            "ude": away,
            "home_goals": home_goals,
            "away_goals": away_goals,
            "result": result,
            "home_odds": kamp.get("home_odds"),
            "draw_odds": kamp.get("draw_odds"),
            "away_odds": kamp.get("away_odds")
        })

    df = pd.DataFrame(records)
    df['bookmaker_spread'] = df.apply(compute_bookmaker_spread, axis=1)
    df["dato"] = pd.to_datetime(df["dato"])
    df.sort_values("dato", inplace=True)
    print(f"[OK] Indlæst {len(df)} afsluttede kampe")
    return df

def beregn_form(df, hold, kamp_dato, dage=None):
    tidligere = df[
        ((df["hjemme"] == hold) | (df["ude"] == hold)) &
        (df["dato"] < kamp_dato)
    ]
    if dage:
        tidligere = tidligere[tidligere["dato"] >= kamp_dato - pd.Timedelta(days=dage)]
    tidligere = tidligere.sort_values("dato", ascending=False).head(5)

    pts, gf, ga = 0, 0, 0
    for _, row in tidligere.iterrows():
        if row["hjemme"] == hold:
            gf += row["home_goals"]
            ga += row["away_goals"]
            pts += 3 if row["home_goals"] > row["away_goals"] else 1 if row["home_goals"] == row["away_goals"] else 0
        else:
            gf += row["away_goals"]
            ga += row["home_goals"]
            pts += 3 if row["away_goals"] > row["home_goals"] else 1 if row["away_goals"] == row["home_goals"] else 0
    return pts, gf, ga

def beregn_h2h(df, hold1, hold2, kamp_dato):
    tidligere = df[
        (((df["hjemme"] == hold1) & (df["ude"] == hold2)) |
         ((df["hjemme"] == hold2) & (df["ude"] == hold1))) &
        (df["dato"] < kamp_dato)
    ]

    wins_1, wins_2, draws = 0, 0, 0
    for _, row in tidligere.iterrows():
        if row["result"] == 1 and row["hjemme"] == hold1:
            wins_1 += 1
        elif row["result"] == -1 and row["ude"] == hold1:
            wins_1 += 1
        elif row["result"] == 1 and row["hjemme"] == hold2:
            wins_2 += 1
        elif row["result"] == -1 and row["ude"] == hold2:
            wins_2 += 1
        else:
            draws += 1
    return wins_1, wins_2, draws

def featurize(df):
    df = df.copy()

    le = LabelEncoder()
    df["hjemme_encoded"] = le.fit_transform(df["hjemme"])
    df["ude_encoded"] = le.fit_transform(df["ude"])
    df["year"] = df["dato"].dt.year
    df["month"] = df["dato"].dt.month
    df["day"] = df["dato"].dt.day

    with open("data/xg_stats.json", "r", encoding="utf-8") as f:
        xg_data = json.load(f)
    with open("data/standings.json", "r", encoding="utf-8") as f:
        standings = json.load(f)
    with open("data/elo_historik.json", "r", encoding="utf-8") as f:
        elo_historik = json.load(f)

    def get_xg_features(hold):
        d = xg_data.get(hold, {})
        return {
            "xG_avg": d.get("xG_avg", 0),
            "xGA_avg": d.get("xGA_avg", 0),
            "xG_diff": d.get("xG_diff", 0),
            "xG_ratio": d.get("xG_ratio", 1)
        }

    def get_standing_features(hold):
        d = standings.get(hold, {})
        return {
            "position": d.get("position", 0),
            "points": d.get("points", 0),
            "gf": d.get("goalsFor", 0),
            "ga": d.get("goalsAgainst", 0)
        }

    def get_elo_features(hold):
        d = elo_historik.get(hold, {})
        return {
            "elo_today": d.get("elo_today", 1500),
            "elo_7d": d.get("elo_7d", 1500),
            "elo_14d": d.get("elo_14d", 1500),
            "elo_30d": d.get("elo_30d", 1500)
        }

    form_data = []
    for _, row in df.iterrows():
        dato = row["dato"]
        hjem = row["hjemme"]
        ude = row["ude"]

        h_pts, h_gf, h_ga = beregn_form(df, hjem, dato)
        u_pts, u_gf, u_ga = beregn_form(df, ude, dato)

        h7, h_gf_7, h_ga_7 = beregn_form(df, hjem, dato, dage=7)
        h30, h_gf_30, h_ga_30 = beregn_form(df, hjem, dato, dage=30)
        u7, u_gf_7, u_ga_7 = beregn_form(df, ude, dato, dage=7)
        u30, u_gf_30, u_ga_30 = beregn_form(df, ude, dato, dage=30)

        h2h_1, h2h_2, h2h_d = beregn_h2h(df, hjem, ude, dato)

        xg_h = get_xg_features(hjem)
        xg_u = get_xg_features(ude)
        s_h = get_standing_features(hjem)
        s_u = get_standing_features(ude)
        elo_h = get_elo_features(hjem)
        elo_u = get_elo_features(ude)

        # 🆕 NEW ADVANCED FEATURES
        form_data.append({
            # Existing features
            "hjemme_last5_pts": h_pts,
            "hjemme_last5_gf": h_gf,
            "hjemme_last5_ga": h_ga,
            "ude_last5_pts": u_pts,
            "ude_last5_gf": u_gf,
            "ude_last5_ga": u_ga,
            "h2h_home_wins": h2h_1,
            "h2h_away_wins": h2h_2,
            "h2h_draws": h2h_d,
            "form_diff": h_pts - u_pts,
            "xg_diff": xg_h["xG_avg"] - xg_u["xG_avg"],
            "expected_ga_gap": xg_u["xGA_avg"] - xg_h["xGA_avg"],
            "standing_diff": s_u["position"] - s_h["position"],
            "mål_diff_5": (h_gf - h_ga) - (u_gf - u_ga),
            "elo_diff": elo_h["elo_today"] - elo_u["elo_today"],
            # REMOVED: "elo_form" - this was a duplicate!
            "momentum_home": h7 - h30,
            "momentum_away": u7 - u30,
            "bookmaker_spread": row.get("bookmaker_spread", 0),
            
            # 🆕 NEW xG FORM FEATURES
            "xg_form_diff": xg_h["xG_avg"] - xg_u["xG_avg"],  # Same as xg_diff but more explicit
            "xga_form_diff": xg_h["xGA_avg"] - xg_u["xGA_avg"],  # Defensive comparison
            
            # 🆕 NEW ELO FORM FEATURES  
            "elo_form_diff": (elo_h["elo_today"] - elo_h["elo_7d"]) - (elo_u["elo_today"] - elo_u["elo_7d"]),
            "elo_momentum_home": elo_h["elo_today"] - elo_h["elo_30d"],
            "elo_momentum_away": elo_u["elo_today"] - elo_u["elo_30d"],
            "elo_momentum_diff": (elo_h["elo_today"] - elo_h["elo_30d"]) - (elo_u["elo_today"] - elo_u["elo_30d"]),
            
            # 🆕 NEW STANDINGS FEATURES
            "standings_diff": s_u["position"] - s_h["position"],  # Positive = home team better position
            "points_diff": s_h["points"] - s_u["points"],
            "goals_for_diff": s_h["gf"] - s_u["gf"],
            "goals_against_diff": s_u["ga"] - s_h["ga"],  # Positive = home team better defense
            
            # 🆕 NEW MOMENTUM FEATURES
            "momentum_diff": (h7 - h30) - (u7 - u30),
            "goals_momentum_home": (h_gf_7 - h_ga_7) - (h_gf_30 - h_ga_30),
            "goals_momentum_away": (u_gf_7 - u_ga_7) - (u_gf_30 - u_ga_30),
            "goals_momentum_diff": ((h_gf_7 - h_ga_7) - (h_gf_30 - h_ga_30)) - ((u_gf_7 - u_ga_7) - (u_gf_30 - u_ga_30)),
            
            # 🆕 NEW COMPOSITE FEATURES
            "overall_strength_diff": (s_h["points"] + xg_h["xG_avg"]*10 + elo_h["elo_today"]/100) - 
                                   (s_u["points"] + xg_u["xG_avg"]*10 + elo_u["elo_today"]/100),
            "form_quality_diff": (h_pts + (h_gf-h_ga)) - (u_pts + (u_gf-u_ga)),
            "elo_standings_correlation": (elo_h["elo_today"] - elo_u["elo_today"]) * (s_u["position"] - s_h["position"]),
            
            # 🆕 WEATHER FEATURES (default values for training data)
            "weather_temperature": 15,  # Default temperature
            "weather_wind": 10,         # Default wind speed
            "weather_rain": 0,          # Default rainfall
            "weather_humidity": 60,     # Default humidity
            "weather_visibility": 10,   # Default visibility
            "weather_poor_conditions": 0,  # Default poor conditions flag
            "weather_extreme": 0        # Default extreme weather flag
        })

    df = pd.concat([df, pd.DataFrame(form_data)], axis=1)

    # === Forbered X og y ===
    feature_columns = [
        "hjemme_encoded", "ude_encoded", "year", "month", "day",
        "hjemme_last5_pts", "hjemme_last5_gf", "hjemme_last5_ga",
        "ude_last5_pts", "ude_last5_gf", "ude_last5_ga",
        "h2h_home_wins", "h2h_away_wins", "h2h_draws",
        "form_diff", "xg_diff", "expected_ga_gap", "standing_diff", "mål_diff_5",
        "elo_diff", "momentum_home", "momentum_away", "bookmaker_spread",  # REMOVED "elo_form"
        # 🆕 NEW FEATURES
        "xg_form_diff", "xga_form_diff",
        "elo_form_diff", "elo_momentum_home", "elo_momentum_away", "elo_momentum_diff", 
        "standings_diff", "points_diff", "goals_for_diff", "goals_against_diff",
        "momentum_diff", "goals_momentum_home", "goals_momentum_away", "goals_momentum_diff",
        "overall_strength_diff", "form_quality_diff", "elo_standings_correlation",
        # 🆕 WEATHER FEATURES
        "weather_temperature", "weather_wind", "weather_rain", "weather_humidity",
        "weather_visibility", "weather_poor_conditions", "weather_extreme"
    ]

    X = df[feature_columns]

    label_map = {-1: 2, 0: 0, 1: 1}
    y = df["result"].map(label_map)

    print(f"✅ Generated {len(feature_columns)} features for training")
    return X, y, df


if __name__ == "__main__":
    df = indlaes_kampe()
    df.to_csv("data/kampe_clean.csv", index=False)
    print("✅ Gemte data/kampe_clean.csv")