import json
import os
from rapidfuzz import fuzz

def build_team_mapping():
    """Build team ID mapping from kampe.json and existing data"""
    
    # Load existing data
    with open("data/kampe.json", "r", encoding="utf-8") as f:
        kampe = json.load(f)
    
    with open("data/xg_stats.json", "r", encoding="utf-8") as f:
        xg_data = json.load(f)
    
    # Extract all unique teams from kampe.json
    football_data_teams = {}
    for kamp in kampe:
        home_team = kamp["homeTeam"]
        away_team = kamp["awayTeam"]
        
        football_data_teams[home_team["id"]] = home_team["name"]
        football_data_teams[away_team["id"]] = away_team["name"]
    
    print(f"📊 Found {len(football_data_teams)} teams in Football-Data.org")
    
    # Get xG team IDs (numbers as strings)
    xg_team_ids = list(xg_data.keys())
    print(f"📊 Found {len(xg_team_ids)} teams in xG data")
    
    # Comprehensive mapping based on xG data analysis
    KNOWN_MAPPINGS = {
        # Premier League (highest xG teams first)
        "87": "Liverpool FC",      # xG_avg: 2.494 (highest)
        "88": "Arsenal FC",        # xG_avg: 2.357  
        "83": "Manchester City FC", # xG_avg: 2.221
        "86": "Manchester United FC", # xG_avg: 2.223
        "82": "Chelsea FC",        # xG_avg: 1.93
        "244": "Tottenham Hotspur FC", # xG_avg: 1.692
        "220": "Newcastle United FC",
        "71": "Aston Villa FC",
        "80": "Brighton & Hove Albion FC", # xG_avg: 2.128
        "249": "West Ham United FC",
        "72": "Crystal Palace FC",
        "73": "Nottingham Forest FC", 
        "78": "AFC Bournemouth",
        "81": "Brentford FC",      # xG_avg: 1.435
        "89": "Fulham FC",
        "228": "Everton FC",
        "256": "Wolverhampton Wanderers FC", # xG_avg: 1.312 (lowest)
        "92": "Leicester City FC",  # xG_avg: 1.143
        "229": "Ipswich Town FC",
        "238": "Southampton FC",   # xG_avg: 1.087
        
        # La Liga 
        "150": "FC Barcelona",     # xG_avg: 2.128
        "148": "Real Madrid CF",   # xG_avg: 2.152
        "223": "Villarreal CF",    # xG_avg: 2.054
        "143": "Athletic Club",    # xG_avg: 1.838
        "147": "Real Betis Balompié", # xG_avg: 1.622
        "154": "RC Celta de Vigo", # xG_avg: 1.574
        "152": "CA Osasuna",       # xG_avg: 1.484
        "153": "Valencia CF",      # xG_avg: 1.393
        "158": "Real Sociedad de Fútbol", # xG_avg: 1.368
        "208": "Girona FC",        # xG_avg: 1.313
        "155": "Rayo Vallecano de Madrid", # xG_avg: 1.147
        "157": "RCD Mallorca",     # xG_avg: 1.205
        "146": "Sevilla FC",       # xG_avg: 1.188
        "142": "Deportivo Alavés", # xG_avg: 1.323
        "239": "RCD Espanyol de Barcelona", # xG_avg: 1.098
        "145": "Getafe CF",        # xG_avg: 1.221
        "140": "CD Leganés",       # xG_avg: 1.294
        "138": "UD Las Palmas",    # xG_avg: 1.409
        "261": "Real Valladolid CF", # xG_avg: 0.999
        "144": "Club Atlético de Madrid", # xG_avg: 0.943
        
        # Bundesliga
        "117": "FC Bayern München", # xG_avg: 2.776 (highest)
        "119": "Bayer 04 Leverkusen", # xG_avg: 2.412
        "133": "Eintracht Frankfurt", # xG_avg: 2.323
        "136": "Borussia Dortmund", # xG_avg: 2.136
        "129": "SC Freiburg",      # xG_avg: 2.093
        "132": "1. FSV Mainz 05",  # xG_avg: 1.519
        "135": "RB Leipzig",       # xG_avg: 1.544
        "130": "SV Werder Bremen", # xG_avg: 1.524
        "125": "VfB Stuttgart",    # xG_avg: 1.52
        "268": "Borussia Mönchengladbach", # xG_avg: 1.513
        "121": "VfL Wolfsburg",    # xG_avg: 1.445
        "240": "FC Augsburg",      # xG_avg: 1.316
        "131": "1. FC Union Berlin", # xG_avg: 1.294
        "280": "FC St. Pauli 1910", # xG_avg: 1.252
        "134": "TSG 1899 Hoffenheim", # xG_avg: 1.304
        "123": "1. FC Heidenheim 1846", # xG_avg: 1.385
        "120": "Holstein Kiel",    # xG_avg: 1.654
        "127": "VfL Bochum 1848",  # xG_avg: 1.017
        
        # Serie A
        "106": "SSC Napoli",       # xG_avg: 2.259
        "111": "FC Internazionale Milano", # xG_avg: 1.891
        "105": "Atalanta BC",      # xG_avg: 1.802
        "107": "Juventus FC",      # xG_avg: 1.802
        "98": "AS Roma",           # xG_avg: 1.671
        "110": "ACF Fiorentina",   # xG_avg: 1.529
        "95": "SS Lazio",          # xG_avg: 1.498
        "97": "AC Milan",          # xG_avg: 1.422
        "96": "Bologna FC 1909",   # xG_avg: 1.352
        "243": "Como 1907",        # xG_avg: 1.253
        "271": "Torino FC",        # xG_avg: 1.199
        "116": "Udinese Calcio",   # xG_avg: 1.196
        "99": "Genoa CFC",         # xG_avg: 1.181
        "104": "Hellas Verona FC", # xG_avg: 1.145
        "113": "Cagliari Calcio",  # xG_avg: 1.139
        "101": "Parma Calcio 1913", # xG_avg: 1.018
        "108": "US Lecce",         # xG_avg: 1.002
        "112": "Empoli FC",        # xG_avg: 1.321
        "94": "Venezia FC",        # xG_avg: 1.012
        "264": "AC Monza",         # xG_avg: 0.828
        
        # Ligue 1
        "161": "Paris Saint-Germain FC", # xG_avg: 2.144
        "210": "Olympique de Marseille", # xG_avg: 1.826
        "171": "AS Monaco FC",     # xG_avg: 1.914
        "164": "OGC Nice",         # xG_avg: 1.766
        "163": "Lille OSC",        # xG_avg: 1.647
        "170": "Olympique Lyonnais", # xG_avg: 1.612
        "241": "RC Strasbourg Alsace", # xG_avg: 1.528
        "178": "Racing Club de Lens", # xG_avg: 1.626
        "160": "Stade Brestois 29", # xG_avg: 1.627
        "174": "Toulouse FC",      # xG_avg: 1.319
        "177": "AJ Auxerre",       # xG_avg: 1.411
        "225": "Stade Rennais FC 1901", # xG_avg: 1.256
        "179": "FC Nantes",        # xG_avg: 1.146
        "180": "Angers SCO",       # xG_avg: 1.011
        "168": "Le Havre AC",      # xG_avg: 1.16
        "166": "Stade de Reims",   # xG_avg: 1.489
        "282": "AS Saint-Étienne", # xG_avg: 1.149
        "270": "Montpellier HSC"   # xG_avg: 1.05
    }
    
    # Apply known mappings
    mapped_data = {}
    for xg_id, xg_stats in xg_data.items():
        if xg_id in KNOWN_MAPPINGS:
            team_name = KNOWN_MAPPINGS[xg_id]
            mapped_data[team_name] = xg_stats
            print(f"✅ Mapped {xg_id} → {team_name}")
        else:
            # Try fuzzy matching with Football-Data teams
            best_match = None
            best_score = 0
            
            for fd_name in football_data_teams.values():
                score = fuzz.ratio(fd_name.lower(), f"team {xg_id}")
                if score > best_score:
                    best_score = score
                    best_match = fd_name
            
            if best_match and best_score > 70:
                mapped_data[best_match] = xg_stats
                print(f"🔍 Fuzzy mapped {xg_id} → {best_match} (score: {best_score})")
            else:
                mapped_data[f"Unknown_Team_{xg_id}"] = xg_stats
                print(f"❓ Could not map {xg_id}")
    
    return mapped_data

def rebuild_xg_file():
    """Rebuild xG file with proper team names"""
    print("🔧 Rebuilding xG file with proper team names...")
    
    # Load original xG data (should have numeric IDs as keys)
    with open("data/xg_stats.json", "r", encoding="utf-8") as f:
        original_xg_data = json.load(f)
    
    # Check if data is already processed (has team names as keys)
    sample_key = list(original_xg_data.keys())[0]
    if not sample_key.isdigit() and not sample_key.startswith("Unknown_Team_"):
        print("✅ xG data already has team names! No rebuild needed.")
        return original_xg_data
    
    # Comprehensive mapping based on xG data analysis
    KNOWN_MAPPINGS = {
        # Premier League (highest xG teams first)
        "87": "Liverpool FC",      # xG_avg: 2.494 (highest)
        "88": "Arsenal FC",        # xG_avg: 2.357  
        "83": "Manchester City FC", # xG_avg: 2.221
        "86": "Manchester United FC", # xG_avg: 2.223
        "82": "Chelsea FC",        # xG_avg: 1.93
        "244": "Tottenham Hotspur FC", # xG_avg: 1.692
        "220": "Newcastle United FC",
        "71": "Aston Villa FC",
        "80": "Brighton & Hove Albion FC", # xG_avg: 2.128
        "249": "West Ham United FC",
        "72": "Crystal Palace FC",
        "73": "Nottingham Forest FC", 
        "78": "AFC Bournemouth",
        "81": "Brentford FC",      # xG_avg: 1.435
        "89": "Fulham FC",
        "228": "Everton FC",
        "256": "Wolverhampton Wanderers FC", # xG_avg: 1.312 (lowest)
        "92": "Leicester City FC",  # xG_avg: 1.143
        "229": "Ipswich Town FC",
        "238": "Southampton FC",   # xG_avg: 1.087
        
        # La Liga 
        "150": "FC Barcelona",     # xG_avg: 2.128
        "148": "Real Madrid CF",   # xG_avg: 2.152
        "223": "Villarreal CF",    # xG_avg: 2.054
        "143": "Athletic Club",    # xG_avg: 1.838
        "147": "Real Betis Balompié", # xG_avg: 1.622
        "154": "RC Celta de Vigo", # xG_avg: 1.574
        "152": "CA Osasuna",       # xG_avg: 1.484
        "153": "Valencia CF",      # xG_avg: 1.393
        "158": "Real Sociedad de Fútbol", # xG_avg: 1.368
        "208": "Girona FC",        # xG_avg: 1.313
        "155": "Rayo Vallecano de Madrid", # xG_avg: 1.147
        "157": "RCD Mallorca",     # xG_avg: 1.205
        "146": "Sevilla FC",       # xG_avg: 1.188
        "142": "Deportivo Alavés", # xG_avg: 1.323
        "239": "RCD Espanyol de Barcelona", # xG_avg: 1.098
        "145": "Getafe CF",        # xG_avg: 1.221
        "140": "CD Leganés",       # xG_avg: 1.294
        "138": "UD Las Palmas",    # xG_avg: 1.409
        "261": "Real Valladolid CF", # xG_avg: 0.999
        "144": "Club Atlético de Madrid", # xG_avg: 0.943
        
        # Bundesliga
        "117": "FC Bayern München", # xG_avg: 2.776 (highest)
        "119": "Bayer 04 Leverkusen", # xG_avg: 2.412
        "133": "Eintracht Frankfurt", # xG_avg: 2.323
        "136": "Borussia Dortmund", # xG_avg: 2.136
        "129": "SC Freiburg",      # xG_avg: 2.093
        "132": "1. FSV Mainz 05",  # xG_avg: 1.519
        "135": "RB Leipzig",       # xG_avg: 1.544
        "130": "SV Werder Bremen", # xG_avg: 1.524
        "125": "VfB Stuttgart",    # xG_avg: 1.52
        "268": "Borussia Mönchengladbach", # xG_avg: 1.513
        "121": "VfL Wolfsburg",    # xG_avg: 1.445
        "240": "FC Augsburg",      # xG_avg: 1.316
        "131": "1. FC Union Berlin", # xG_avg: 1.294
        "280": "FC St. Pauli 1910", # xG_avg: 1.252
        "134": "TSG 1899 Hoffenheim", # xG_avg: 1.304
        "123": "1. FC Heidenheim 1846", # xG_avg: 1.385
        "120": "Holstein Kiel",    # xG_avg: 1.654
        "127": "VfL Bochum 1848",  # xG_avg: 1.017
        
        # Serie A
        "106": "SSC Napoli",       # xG_avg: 2.259
        "111": "FC Internazionale Milano", # xG_avg: 1.891
        "105": "Atalanta BC",      # xG_avg: 1.802
        "107": "Juventus FC",      # xG_avg: 1.802
        "98": "AS Roma",           # xG_avg: 1.671
        "110": "ACF Fiorentina",   # xG_avg: 1.529
        "95": "SS Lazio",          # xG_avg: 1.498
        "97": "AC Milan",          # xG_avg: 1.422
        "96": "Bologna FC 1909",   # xG_avg: 1.352
        "243": "Como 1907",        # xG_avg: 1.253
        "271": "Torino FC",        # xG_avg: 1.199
        "116": "Udinese Calcio",   # xG_avg: 1.196
        "99": "Genoa CFC",         # xG_avg: 1.181
        "104": "Hellas Verona FC", # xG_avg: 1.145
        "113": "Cagliari Calcio",  # xG_avg: 1.139
        "101": "Parma Calcio 1913", # xG_avg: 1.018
        "108": "US Lecce",         # xG_avg: 1.002
        "112": "Empoli FC",        # xG_avg: 1.321
        "94": "Venezia FC",        # xG_avg: 1.012
        "264": "AC Monza",         # xG_avg: 0.828
        
        # Ligue 1
        "161": "Paris Saint-Germain FC", # xG_avg: 2.144
        "210": "Olympique de Marseille", # xG_avg: 1.826
        "171": "AS Monaco FC",     # xG_avg: 1.914
        "164": "OGC Nice",         # xG_avg: 1.766
        "163": "Lille OSC",        # xG_avg: 1.647
        "170": "Olympique Lyonnais", # xG_avg: 1.612
        "241": "RC Strasbourg Alsace", # xG_avg: 1.528
        "178": "Racing Club de Lens", # xG_avg: 1.626
        "160": "Stade Brestois 29", # xG_avg: 1.627
        "174": "Toulouse FC",      # xG_avg: 1.319
        "177": "AJ Auxerre",       # xG_avg: 1.411
        "225": "Stade Rennais FC 1901", # xG_avg: 1.256
        "179": "FC Nantes",        # xG_avg: 1.146
        "180": "Angers SCO",       # xG_avg: 1.011
        "168": "Le Havre AC",      # xG_avg: 1.16
        "166": "Stade de Reims",   # xG_avg: 1.489
        "282": "AS Saint-Étienne", # xG_avg: 1.149
        "270": "Montpellier HSC"   # xG_avg: 1.05
    }
    
    # Process each team
    mapped_data = {}
    successful_mappings = 0
    
    for team_id, xg_stats in original_xg_data.items():
        # Clean team_id (remove any existing prefixes)
        clean_id = team_id.replace("Unknown_Team_", "")
        
        if clean_id in KNOWN_MAPPINGS:
            team_name = KNOWN_MAPPINGS[clean_id]
            mapped_data[team_name] = xg_stats
            successful_mappings += 1
            print(f"✅ Mapped {clean_id} → {team_name}")
        else:
            mapped_data[f"Unknown_Team_{clean_id}"] = xg_stats
            print(f"❓ Could not map {clean_id}")
    
    # Save the corrected data
    with open("data/xg_stats_fixed.json", "w", encoding="utf-8") as f:
        json.dump(mapped_data, f, indent=2, ensure_ascii=False)
    
    # Replace original file
    os.rename("data/xg_stats_fixed.json", "data/xg_stats.json")
    
    print(f"✅ Rebuilt xG file with {len(mapped_data)} teams")
    print(f"🎯 {successful_mappings} teams successfully mapped to real names")
    
    return mapped_data

if __name__ == "__main__":
    rebuild_xg_file()