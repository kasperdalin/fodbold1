import requests
import json
import os

API_KEY = "3ea7581f7fa34b1fbb5d58ffc46a5821"  # ← din eksisterende API-nøgle
BASE_URL = "https://api.football-data.org/v4"
HEADERS = {"X-Auth-Token": API_KEY}

LIGAER = {
    "PL": "Premier League",
    "PD": "La Liga",
    "SA": "Serie A",
    "BL1": "Bundesliga",
    "FL1": "Ligue 1"
}

SAVE_PATH = "data/standings.json"

def hent_stillinger():
    all_teams = {}

    for kode, liga_navn in LIGAER.items():
        url = f"{BASE_URL}/competitions/{kode}/standings"
        print(f"🔄 Henter stilling for {liga_navn}...")

        try:
            response = requests.get(url, headers=HEADERS)
            response.raise_for_status()
            data = response.json()

            standings = data.get("standings", [])
            if not standings:
                print(f"⚠️ Ingen stilling fundet for {liga_navn}")
                continue

            for row in standings[0]["table"]:
                team = row["team"]["name"]
                all_teams[team] = {
                    "league": liga_navn,
                    "position": row["position"],
                    "points": row["points"],
                    "goalsFor": row["goalsFor"],
                    "goalsAgainst": row["goalsAgainst"]
                }

        except Exception as e:
            print(f"❌ Fejl ved {liga_navn}: {e}")

    os.makedirs("data", exist_ok=True)
    with open(SAVE_PATH, "w", encoding="utf-8") as f:
        json.dump(all_teams, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Gemte standings for {len(all_teams)} hold i {SAVE_PATH}")

if __name__ == "__main__":
    hent_stillinger()
