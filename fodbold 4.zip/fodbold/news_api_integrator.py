import requests
import json
from datetime import datetime, timedelta
from textblob import TextBlob
import time
import re

class FootballNewsAnalyzer:
    """
    NewsAPI integration for football team psychology and sentiment
    """
    
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://newsapi.org/v2/everything"
        self.last_request_time = 0
        self.min_request_interval = 1  # 1 second between requests
        
        # Keywords that indicate different types of news
        self.manager_pressure_keywords = [
            "sacked", "fired", "under pressure", "job on the line", 
            "board meeting", "future uncertain", "contract extension denied"
        ]
        
        self.controversy_keywords = [
            "scandal", "controversy", "arrested", "banned", "fine",
            "disciplinary", "investigation", "suspended", "misconduct"
        ]
        
        self.injury_keywords = [
            "injured", "injury", "out for", "sidelined", "surgery",
            "recovery", "fitness test", "doubt for", "ruled out"
        ]
        
        self.positive_keywords = [
            "record signing", "new contract", "brilliant", "excellent",
            "outstanding", "victory", "win", "success", "trophy"
        ]

    def rate_limit(self):
        """Ensure we don't exceed rate limits"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
        
        self.last_request_time = time.time()

    def get_team_news(self, team_name, days_back=7, max_articles=50):
        """
        Get recent news articles about a football team
        """
        self.rate_limit()
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        # Build search query - more specific for football
        search_terms = [
            f'"{team_name}"',
            f'{team_name} football',
            f'{team_name} soccer',
            f'{team_name} FC',
            f'{team_name} manager',
            f'{team_name} players'
        ]
        
        query = ' OR '.join(search_terms)
        
        params = {
            'q': query,
            'from': start_date.strftime('%Y-%m-%d'),
            'to': end_date.strftime('%Y-%m-%d'),
            'language': 'en',
            'sortBy': 'relevancy',
            'pageSize': min(max_articles, 100),  # API limit is 100
            'apiKey': self.api_key
        }
        
        try:
            response = requests.get(self.base_url, params=params, timeout=10)
            data = response.json()
            
            if data.get('status') == 'ok':
                articles = data.get('articles', [])
                print(f"📰 Found {len(articles)} articles for {team_name}")
                return articles
            else:
                print(f"❌ NewsAPI error: {data.get('message', 'Unknown error')}")
                return []
                
        except Exception as e:
            print(f"❌ Error fetching news for {team_name}: {e}")
            return []

    def analyze_sentiment(self, articles, team_name):
        """
        Analyze sentiment of news articles about team
        """
        if not articles:
            return self._default_sentiment()
        
        sentiments = []
        relevance_scores = []
        
        for article in articles:
            title = article.get('title', '') or ''
            description = article.get('description', '') or ''
            content = f"{title} {description}".lower()
            
            # Check if article is actually about our team
            team_mentions = content.count(team_name.lower())
            if team_mentions == 0:
                continue
            
            # Calculate relevance (more mentions = more relevant)
            relevance = min(team_mentions * 0.3, 1.0)
            
            # Sentiment analysis using TextBlob
            try:
                blob = TextBlob(content)
                sentiment = blob.sentiment.polarity  # -1 (negative) to 1 (positive)
                
                sentiments.append(sentiment)
                relevance_scores.append(relevance)
                
            except Exception as e:
                print(f"⚠️ Sentiment analysis error: {e}")
                continue
        
        if not sentiments:
            return self._default_sentiment()
        
        # Calculate weighted average sentiment
        weighted_sentiment = sum(s * r for s, r in zip(sentiments, relevance_scores))
        total_weight = sum(relevance_scores)
        avg_sentiment = weighted_sentiment / total_weight if total_weight > 0 else 0
        
        # Categorize sentiment
        if avg_sentiment > 0.1:
            category = 'positive'
        elif avg_sentiment < -0.1:
            category = 'negative'
        else:
            category = 'neutral'
        
        return {
            'sentiment_score': round(avg_sentiment, 3),
            'sentiment_category': category,
            'articles_analyzed': len(sentiments),
            'confidence': min(len(sentiments) / 10, 1.0)  # More articles = higher confidence
        }

    def detect_manager_pressure(self, articles):
        """
        Detect if manager is under pressure based on news
        """
        pressure_indicators = 0
        total_articles = len(articles)
        
        for article in articles:
            content = f"{article.get('title', '')} {article.get('description', '')}".lower()
            
            # Count pressure indicators
            for keyword in self.manager_pressure_keywords:
                if keyword in content:
                    pressure_indicators += 1
                    break  # Count max 1 per article
        
        # Calculate pressure level (0-1)
        pressure_level = min(pressure_indicators / max(total_articles * 0.1, 1), 1.0)
        
        return {
            'manager_pressure_level': round(pressure_level, 3),
            'pressure_indicators': pressure_indicators,
            'high_pressure': pressure_level > 0.3
        }

    def detect_controversies(self, articles):
        """
        Detect team controversies and scandals
        """
        controversy_count = 0
        
        for article in articles:
            content = f"{article.get('title', '')} {article.get('description', '')}".lower()
            
            for keyword in self.controversy_keywords:
                if keyword in content:
                    controversy_count += 1
                    break
        
        controversy_level = min(controversy_count / max(len(articles) * 0.05, 1), 1.0)
        
        return {
            'controversy_level': round(controversy_level, 3),
            'controversy_count': controversy_count,
            'high_controversy': controversy_level > 0.2
        }

    def detect_injury_concerns(self, articles):
        """
        Detect injury-related news
        """
        injury_mentions = 0
        
        for article in articles:
            content = f"{article.get('title', '')} {article.get('description', '')}".lower()
            
            for keyword in self.injury_keywords:
                if keyword in content:
                    injury_mentions += 1
                    break
        
        injury_concern_level = min(injury_mentions / max(len(articles) * 0.1, 1), 1.0)
        
        return {
            'injury_concern_level': round(injury_concern_level, 3),
            'injury_mentions': injury_mentions,
            'high_injury_concerns': injury_concern_level > 0.3
        }

    def get_team_psychology_features(self, team_name, days_back=7):
        """
        Get comprehensive psychology features for a team
        """
        print(f"🧠 Analyzing {team_name} psychology from news...")
        
        # Get news articles
        articles = self.get_team_news(team_name, days_back)
        
        if not articles:
            return self._default_features(team_name)
        
        # Analyze different aspects
        sentiment = self.analyze_sentiment(articles, team_name)
        manager_pressure = self.detect_manager_pressure(articles)
        controversies = self.detect_controversies(articles)
        injury_concerns = self.detect_injury_concerns(articles)
        
        # Combine into features
        features = {
            'team': team_name,
            'news_sentiment_score': sentiment['sentiment_score'],
            'news_sentiment_category': sentiment['sentiment_category'],
            'news_confidence': sentiment['confidence'],
            'manager_pressure_level': manager_pressure['manager_pressure_level'],
            'manager_under_pressure': 1 if manager_pressure['high_pressure'] else 0,
            'controversy_level': controversies['controversy_level'],
            'high_controversy': 1 if controversies['high_controversy'] else 0,
            'injury_concern_level': injury_concerns['injury_concern_level'],
            'high_injury_concerns': 1 if injury_concerns['high_injury_concerns'] else 0,
            'articles_analyzed': len(articles),
            'news_activity': min(len(articles) / 20, 1.0)  # How much the team is in the news
        }
        
        print(f"✅ Psychology analysis complete for {team_name}")
        return features

    def _default_sentiment(self):
        return {
            'sentiment_score': 0.0,
            'sentiment_category': 'neutral',
            'articles_analyzed': 0,
            'confidence': 0.0
        }

    def _default_features(self, team_name):
        return {
            'team': team_name,
            'news_sentiment_score': 0.0,
            'news_sentiment_category': 'neutral',
            'news_confidence': 0.0,
            'manager_pressure_level': 0.0,
            'manager_under_pressure': 0,
            'controversy_level': 0.0,
            'high_controversy': 0,
            'injury_concern_level': 0.0,
            'high_injury_concerns': 0,
            'articles_analyzed': 0,
            'news_activity': 0.0
        }

# Test function - NOW WITH ALL 5 LEAGUES
def test_news_analyzer():
    """Test the news analyzer with teams from all major leagues"""
    
    API_KEY = "72fd719905ec4f3fa96e3e73c75ae6e2"
    
    if API_KEY == "YOUR_NEWSAPI_KEY_HERE":
        print("❌ Please add your NewsAPI key!")
        return
    
    analyzer = FootballNewsAnalyzer(API_KEY)
    
    # Test teams from ALL 5 major leagues
    test_teams = [
        # Premier League 🏴󠁧󠁢󠁥󠁮󠁧󠁿
        "Liverpool FC", "Arsenal FC", "Manchester City FC",
        # La Liga 🇪🇸
        "Real Madrid CF", "FC Barcelona", "Atletico Madrid",
        # Bundesliga 🇩🇪
        "FC Bayern Munich", "Borussia Dortmund", "RB Leipzig", 
        # Serie A 🇮🇹
        "Juventus FC", "AC Milan", "Inter Milan",
        # Ligue 1 🇫🇷
        "Paris Saint-Germain FC", "AS Monaco FC", "Olympique de Marseille"
    ]
    
    print(f"🌍 Testing {len(test_teams)} teams from 5 major leagues...")
    print("🏴󠁧󠁢󠁥󠁮󠁧󠁿 Premier League | 🇪🇸 La Liga | 🇩🇪 Bundesliga | 🇮🇹 Serie A | 🇫🇷 Ligue 1")
    print("="*80)
    
    for i, team in enumerate(test_teams):
        # Add league indicators
        if i < 3:
            league_flag = "🏴󠁧󠁢󠁥󠁮󠁧󠁿"
        elif i < 6:
            league_flag = "🇪🇸"
        elif i < 9:
            league_flag = "🇩🇪"
        elif i < 12:
            league_flag = "🇮🇹"
        else:
            league_flag = "🇫🇷"
        
        print(f"\n{league_flag} Testing: {team}")
        print("-" * 50)
        
        features = analyzer.get_team_psychology_features(team, days_back=7)
        
        print(f"📊 PSYCHOLOGY SUMMARY:")
        print(f"  Sentiment: {features['news_sentiment_score']} ({features['news_sentiment_category']})")
        print(f"  Manager Pressure: {features['manager_pressure_level']}")
        print(f"  Controversies: {features['controversy_level']}")
        print(f"  Injury Concerns: {features['injury_concern_level']}")
        print(f"  News Activity: {features['news_activity']}")
        print(f"  Articles Analyzed: {features['articles_analyzed']}")
        
        # Rate limiting - be nice to API
        time.sleep(2)
    
    print("\n🎉 MULTI-LEAGUE PSYCHOLOGY ANALYSIS COMPLETE!")
    print("✅ Your system now has data from all 5 major European leagues!")

if __name__ == "__main__":
    test_news_analyzer()