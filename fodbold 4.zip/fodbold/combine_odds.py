import json
from odds_api import hent_odds
from rapidfuzz import fuzz  # nyt import for fuzzy matching

BETFAIR_PATH = "data/betfair_odds.json"

def hent_betfair_odds():
    try:
        with open(BETFAIR_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[FEJL] Kunne ikke læse betfair_odds.json: {e}")
        return []

def match_kampe(hjemme, ude, odds_api_data, betfair_data):
    kamp_id = f"{hjemme} vs {ude}"
    odds_api_odds = odds_api_data.get(kamp_id, {"1": 2.0, "X": 3.5, "2": 3.0})

    def is_match(a, b):
        return fuzz.partial_ratio(a.lower(), b.lower()) >= 85

    for kamp in betfair_data:
        home_api = kamp["home_team"]
        away_api = kamp["away_team"]

        if is_match(home_api, hjemme) and is_match(away_api, ude):
            odds_betfair = kamp.get("odds", {})
            odds = {
                "1": odds_betfair.get(home_api, 2.0),
                "X": odds_betfair.get("The Draw", 3.5),
                "2": odds_betfair.get(away_api, 3.0)
            }

            avg = {
                "1": round((odds["1"] + odds_api_odds["1"]) / 2, 3),
                "X": round((odds["X"] + odds_api_odds["X"]) / 2, 3),
                "2": round((odds["2"] + odds_api_odds["2"]) / 2, 3)
            }

            return {
                "betfair": odds,
                "bookmakers": odds_api_odds,
                "average": avg
            }

    return {
        "betfair": None,
        "bookmakers": odds_api_odds,
        "average": odds_api_odds
    }

def hent_kombinerede_odds():
    raw_odds = hent_odds()
    odds_api_data = {}

    for kamp in raw_odds:
        try:
            key = f"{kamp['home_team']} vs {kamp['away_team']}"
            if kamp["bookmakers"]:
                first = kamp["bookmakers"][0]["odds"]
                if all(v is not None for v in first.values()):
                    odds_api_data[key] = {
                        "1": first["1"],
                        "X": first["X"],
                        "2": first["2"]
                    }
        except Exception as e:
            print(f"[FEJL i odds_api]: {e}")

    betfair_data = hent_betfair_odds()
    return odds_api_data, betfair_data, match_kampe
