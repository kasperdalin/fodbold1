import json
import pandas as pd
import os
from datetime import datetime
import statistics
from rapidfuzz import fuzz
import requests
from integrate_news_features import NewsFeatureIntegrator

XG_PATH = "data/xg_stats.json"
STANDINGS_PATH = "data/standings.json"
ELO_PATH = "data/elo_historik.json"
KAMPE_PATH = "data/kampe.json"
ODDS_PATH = "data/odds_data.json"

# 🌦️ WEATHER API CONFIGURATION
WEATHER_API_KEY = "c73c66550b764bce8ae224549250406"  # ⚠️ INDSÆT DIN API KEY HER!
WEATHER_BASE_URL = "http://api.weatherapi.com/v1/forecast.json"
NEWS_API_KEY = "72fd719905ec4f3fa96e3e73c75ae6e2"

# 🏟️ STADIUM LOCATIONS DATABASE
STADIUM_LOCATIONS = {
    # Premier League
    "Arsenal FC": "London, UK",
    "Aston Villa FC": "Birmingham, UK", 
    "AFC Bournemouth": "Bournemouth, UK",
    "Brentford FC": "London, UK",
    "Brighton & Hove Albion FC": "Brighton, UK",
    "Chelsea FC": "London, UK",
    "Crystal Palace FC": "London, UK",
    "Everton FC": "Liverpool, UK",
    "Fulham FC": "London, UK",
    "Ipswich Town FC": "Ipswich, UK",
    "Leicester City FC": "Leicester, UK",
    "Liverpool FC": "Liverpool, UK",
    "Manchester City FC": "Manchester, UK",
    "Manchester United FC": "Manchester, UK",
    "Newcastle United FC": "Newcastle, UK",
    "Nottingham Forest FC": "Nottingham, UK",
    "Southampton FC": "Southampton, UK",
    "Tottenham Hotspur FC": "London, UK",
    "West Ham United FC": "London, UK",
    "Wolverhampton Wanderers FC": "Wolverhampton, UK",
    
    # La Liga  
    "FC Barcelona": "Barcelona, Spain",
    "Real Madrid CF": "Madrid, Spain",
    "Club Atlético de Madrid": "Madrid, Spain",
    "Athletic Club": "Bilbao, Spain",
    "Villarreal CF": "Villarreal, Spain",
    "Real Betis Balompié": "Seville, Spain",
    "RC Celta de Vigo": "Vigo, Spain",
    "CA Osasuna": "Pamplona, Spain",
    "Valencia CF": "Valencia, Spain",
    "Real Sociedad de Fútbol": "San Sebastian, Spain",
    "Girona FC": "Girona, Spain",
    "Rayo Vallecano de Madrid": "Madrid, Spain",
    "RCD Mallorca": "Palma, Spain",
    "Sevilla FC": "Seville, Spain",
    "Deportivo Alavés": "Vitoria, Spain",
    "RCD Espanyol de Barcelona": "Barcelona, Spain",
    "Getafe CF": "Getafe, Spain",
    "CD Leganés": "Leganes, Spain",
    "UD Las Palmas": "Las Palmas, Spain",
    "Real Valladolid CF": "Valladolid, Spain",
    
    # Serie A
    "SSC Napoli": "Naples, Italy",
    "FC Internazionale Milano": "Milan, Italy",
    "Atalanta BC": "Bergamo, Italy",
    "Juventus FC": "Turin, Italy",
    "AS Roma": "Rome, Italy",
    "ACF Fiorentina": "Florence, Italy",
    "SS Lazio": "Rome, Italy",
    "AC Milan": "Milan, Italy",
    "Bologna FC 1909": "Bologna, Italy",
    "Como 1907": "Como, Italy",
    "Torino FC": "Turin, Italy",
    "Udinese Calcio": "Udine, Italy",
    "Genoa CFC": "Genoa, Italy",
    "Hellas Verona FC": "Verona, Italy",
    "Cagliari Calcio": "Cagliari, Italy",
    "Parma Calcio 1913": "Parma, Italy",
    "US Lecce": "Lecce, Italy",
    "Empoli FC": "Empoli, Italy",
    "Venezia FC": "Venice, Italy",
    "AC Monza": "Monza, Italy",
    
    # Bundesliga
    "FC Bayern München": "Munich, Germany",
    "Bayer 04 Leverkusen": "Leverkusen, Germany",
    "Eintracht Frankfurt": "Frankfurt, Germany",
    "Borussia Dortmund": "Dortmund, Germany",
    "SC Freiburg": "Freiburg, Germany",
    "1. FSV Mainz 05": "Mainz, Germany",
    "RB Leipzig": "Leipzig, Germany",
    "SV Werder Bremen": "Bremen, Germany",
    "VfB Stuttgart": "Stuttgart, Germany",
    "Borussia Mönchengladbach": "Mönchengladbach, Germany",
    "VfL Wolfsburg": "Wolfsburg, Germany",
    "FC Augsburg": "Augsburg, Germany",
    "1. FC Union Berlin": "Berlin, Germany",
    "FC St. Pauli 1910": "Hamburg, Germany",
    "TSG 1899 Hoffenheim": "Hoffenheim, Germany",
    "1. FC Heidenheim 1846": "Heidenheim, Germany",
    "Holstein Kiel": "Kiel, Germany",
    "VfL Bochum 1848": "Bochum, Germany",
    
    # Ligue 1
    "Paris Saint-Germain FC": "Paris, France",
    "Olympique de Marseille": "Marseille, France",
    "AS Monaco FC": "Monaco, France",
    "OGC Nice": "Nice, France",
    "Lille OSC": "Lille, France",
    "Olympique Lyonnais": "Lyon, France",
    "RC Strasbourg Alsace": "Strasbourg, France",
    "Racing Club de Lens": "Lens, France",
    "Stade Brestois 29": "Brest, France",
    "Toulouse FC": "Toulouse, France",
    "AJ Auxerre": "Auxerre, France",
    "Stade Rennais FC 1901": "Rennes, France",
    "FC Nantes": "Nantes, France",
    "Angers SCO": "Angers, France",
    "Le Havre AC": "Le Havre, France",
    "Stade de Reims": "Reims, France",
    "AS Saint-Étienne": "Saint-Etienne, France",
    "Montpellier HSC": "Montpellier, France"
}

def get_weather_for_match(home_team, match_date):
    """
    🌦️ Hent vejr data for en specifik kamp
    
    Args:
        home_team (str): Hjemmeholdets navn
        match_date (str): Kampdato i format "2025-06-15T15:00:00Z"
    
    Returns:
        dict: Vejr features eller None hvis fejl
    """
    
    if WEATHER_API_KEY == "YOUR_API_KEY_HERE":
        print("⚠️ Weather API key ikke sat - bruger default values")
        return None
    
    # Get stadium location
    location = STADIUM_LOCATIONS.get(home_team, "Unknown")
    if location == "Unknown":
        print(f"⚠️ Ukendt lokation for {home_team}")
        return None
    
    # Parse match date
    try:
        match_datetime = datetime.fromisoformat(match_date.replace('Z', '+00:00'))
        date_str = match_datetime.strftime('%Y-%m-%d')
    except:
        print(f"❌ Kunne ikke parse dato: {match_date}")
        return None
    
    # API request
    try:
        params = {
            'key': WEATHER_API_KEY,
            'q': location,
            'dt': date_str,
            'aqi': 'no'
        }
        
        response = requests.get(WEATHER_BASE_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # Extract weather features
        forecast_day = data['forecast']['forecastday'][0]['day']
        
        weather_data = {
            'temperature_avg': forecast_day['avgtemp_c'],
            'temperature_max': forecast_day['maxtemp_c'],
            'temperature_min': forecast_day['mintemp_c'],
            'wind_speed': forecast_day['maxwind_kph'],
            'precipitation': forecast_day['totalprecip_mm'],
            'humidity': forecast_day['avghumidity'],
            'visibility': forecast_day['avgvis_km'],
            'uv_index': forecast_day['uv'],
            'condition': forecast_day['condition']['text']
        }
        
        print(f"🌦️ Vejr hentet for {home_team} ({location}): {weather_data['condition']}, {weather_data['temperature_avg']}°C")
        return weather_data
        
    except Exception as e:
        print(f"❌ Fejl ved vejr API for {home_team}: {e}")
        return None

def add_weather_features(weather_data):
    """
    🌦️ Konverter råt vejr data til ML features
    
    Args:
        weather_data (dict): Råt vejr data
    
    Returns:
        dict: ML-klar features
    """
    
    if not weather_data:
        return {
            'weather_temperature': 15,  # Default values
            'weather_wind': 10,
            'weather_rain': 0,
            'weather_humidity': 60,
            'weather_visibility': 10,
            'weather_poor_conditions': 0,
            'weather_extreme': 0
        }
    
    # Create ML features
    features = {
        'weather_temperature': weather_data['temperature_avg'],
        'weather_wind': weather_data['wind_speed'], 
        'weather_rain': weather_data['precipitation'],
        'weather_humidity': weather_data['humidity'],
        'weather_visibility': weather_data['visibility']
    }
    
    # Add derived features
    features['weather_poor_conditions'] = 0
    
    # Poor weather conditions (these typically reduce goals)
    if (weather_data['precipitation'] > 5 or          # Heavy rain
        weather_data['wind_speed'] > 25 or           # Strong wind  
        weather_data['visibility'] < 5 or            # Poor visibility
        weather_data['temperature_avg'] < 2 or       # Very cold
        weather_data['temperature_avg'] > 35):       # Very hot
        
        features['weather_poor_conditions'] = 1
    
    # Extreme weather flag
    features['weather_extreme'] = 0
    if (weather_data['precipitation'] > 15 or         # Very heavy rain
        weather_data['wind_speed'] > 40 or           # Very strong wind
        weather_data['temperature_avg'] < -2 or      # Freezing
        weather_data['temperature_avg'] > 40):       # Extreme heat
        
        features['weather_extreme'] = 1
    
    return features

def get_bookmaker_spread(kamp, odds_data):
    """Calculate bookmaker spread from odds data with fuzzy matching"""
    if not odds_data:
        return None

    hjemme_team = kamp["hjemme"]
    ude_team = kamp["ude"]
    
    # Check exact match first
    for game in odds_data:
        if (game["home_team"] == hjemme_team and game["away_team"] == ude_team):
            try:
                odds_values = [game["odds"]["1"], game["odds"]["X"], game["odds"]["2"]]
                return round(statistics.stdev(odds_values), 3) if len(odds_values) > 1 else 0
            except:
                continue
    
    # Fuzzy matching fallback
    best_match = None
    best_score = 0
    
    for game in odds_data:
        home_score = fuzz.ratio(game["home_team"].lower(), hjemme_team.lower())
        away_score = fuzz.ratio(game["away_team"].lower(), ude_team.lower())
        total_score = (home_score + away_score) / 2
        
        if total_score > best_score and total_score > 80:
            best_score = total_score
            best_match = game
    
    if best_match:
        try:
            odds_values = [best_match["odds"]["1"], best_match["odds"]["X"], best_match["odds"]["2"]]
            return round(statistics.stdev(odds_values), 3) if len(odds_values) > 1 else 0
        except:
            pass
    
    return None

def hent_historiske_kampe():
    if not os.path.exists(KAMPE_PATH):
        return pd.DataFrame()

    with open(KAMPE_PATH, "r", encoding="utf-8") as f:
        kampe = json.load(f)

    records = []
    for kamp in kampe:
        if kamp["status"] != "FINISHED":
            continue
        home = kamp["homeTeam"]["name"]
        away = kamp["awayTeam"]["name"]
        date = kamp["utcDate"]
        full_time = kamp["score"].get("fullTime", {})
        home_goals = full_time.get("home", 0)
        away_goals = full_time.get("away", 0)

        if home_goals > away_goals:
            result = 1
        elif home_goals < away_goals:
            result = 2
        else:
            result = 0

        records.append({
            "dato": date,
            "hjemme": home,
            "ude": away,
            "home_goals": home_goals,
            "away_goals": away_goals,
            "result": result
        })

    df = pd.DataFrame(records)
    df["dato"] = pd.to_datetime(df["dato"])
    return df.sort_values("dato")

def beregn_form(df, hold, kamp_dato, days=None):
    filtreret = df[
        ((df["hjemme"] == hold) | (df["ude"] == hold)) &
        (df["dato"] < kamp_dato)
    ]
    if days:
        filtreret = filtreret[filtreret["dato"] > kamp_dato - pd.Timedelta(days=days)]

    filtreret = filtreret.sort_values("dato", ascending=False).head(5)
    pts, gf, ga = 0, 0, 0
    for _, row in filtreret.iterrows():
        if row["hjemme"] == hold:
            gf += row["home_goals"]
            ga += row["away_goals"]
            pts += 3 if row["home_goals"] > row["away_goals"] else 1 if row["home_goals"] == row["away_goals"] else 0
        else:
            gf += row["away_goals"]
            ga += row["home_goals"]
            pts += 3 if row["away_goals"] > row["home_goals"] else 1 if row["away_goals"] == row["home_goals"] else 0
    return pts, gf, ga

def beregn_h2h(df, hold1, hold2, kamp_dato):
    tidligere = df[
        (((df["hjemme"] == hold1) & (df["ude"] == hold2)) |
         ((df["hjemme"] == hold2) & (df["ude"] == hold1))) &
        (df["dato"] < kamp_dato)
    ]
    wins_1, wins_2, draws = 0, 0, 0
    for _, row in tidligere.iterrows():
        if row["result"] == 1 and row["hjemme"] == hold1:
            wins_1 += 1
        elif row["result"] == 2 and row["ude"] == hold1:
            wins_1 += 1
        elif row["result"] == 1 and row["hjemme"] == hold2:
            wins_2 += 1
        elif row["result"] == 2 and row["ude"] == hold2:
            wins_2 += 1
        else:
            draws += 1
    return wins_1, wins_2, draws

def get_xg_features(hold, xg_data):
    d = xg_data.get(hold, {})
    return {
        "xG_avg": d.get("xG_avg", 0),
        "xGA_avg": d.get("xGA_avg", 0),
        "xG_diff": d.get("xG_diff", 0),
        "xG_ratio": d.get("xG_ratio", 1)
    }

def get_standings_features(hold, standings):
    d = standings.get(hold, {})
    return {
        "position": d.get("position", 0),
        "points": d.get("points", 0),
        "gf": d.get("goalsFor", 0),
        "ga": d.get("goalsAgainst", 0)
    }

def get_elo_features(hjem, ude, elo_data):
    h = elo_data.get(hjem, {})
    u = elo_data.get(ude, {})
    h_today, h_7d, h_14d, h_30d = h.get("elo_today", 1500), h.get("elo_7d", 1500), h.get("elo_14d", 1500), h.get("elo_30d", 1500)
    u_today, u_7d, u_14d, u_30d = u.get("elo_today", 1500), u.get("elo_7d", 1500), u.get("elo_14d", 1500), u.get("elo_30d", 1500)
    return {
        "elo_diff": h_today - u_today,
        "elo_form_diff": (h_today - h_7d) - (u_today - u_7d),
        "elo_home_adv": h_today - h_30d,
        "elo_home_today": h_today,
        "elo_home_7d": h_7d,
        "elo_home_14d": h_14d,
        "elo_home_30d": h_30d,
        "elo_away_today": u_today,
        "elo_away_7d": u_7d,
        "elo_away_14d": u_14d,
        "elo_away_30d": u_30d
    }

def featurize_kommende_kampe(kampe):
    df_hist = hent_historiske_kampe()

    with open(XG_PATH, "r", encoding="utf-8") as f:
        xg_data = json.load(f)
    with open(STANDINGS_PATH, "r", encoding="utf-8") as f:
        standings = json.load(f)
    with open(ELO_PATH, "r", encoding="utf-8") as f:
        elo_data = json.load(f)
    with open(ODDS_PATH, "r", encoding="utf-8") as f:
        odds_data = json.load(f)

    unikke_hold = set()
    for k in kampe:
        unikke_hold.add(k["hjemme"])
        unikke_hold.add(k["ude"])
    hold_map = {navn: i for i, navn in enumerate(sorted(unikke_hold))}

    records = []
    for kamp in kampe:
        hjem = kamp["hjemme"]
        ude = kamp["ude"]
        kamp_dato = pd.to_datetime(kamp["dato"], utc=True)

        # 🌦️ WEATHER FEATURES - NEW!
        print(f"🌦️ Henter vejr for {hjem} vs {ude}...")
        weather_data = get_weather_for_match(hjem, kamp["dato"])
        weather_features = add_weather_features(weather_data)

        h_form = beregn_form(df_hist, hjem, kamp_dato)
        u_form = beregn_form(df_hist, ude, kamp_dato)
        h_form_7 = beregn_form(df_hist, hjem, kamp_dato, days=7)
        h_form_30 = beregn_form(df_hist, hjem, kamp_dato, days=30)
        u_form_7 = beregn_form(df_hist, ude, kamp_dato, days=7)
        u_form_30 = beregn_form(df_hist, ude, kamp_dato, days=30)
        h2h = beregn_h2h(df_hist, hjem, ude, kamp_dato)
        xg_h = get_xg_features(hjem, xg_data)
        xg_u = get_xg_features(ude, xg_data)
        s_h = get_standings_features(hjem, standings)
        s_u = get_standings_features(ude, standings)
        elo_feats = get_elo_features(hjem, ude, elo_data)
        spread = get_bookmaker_spread(kamp, odds_data)
        # Add psychology features
        news_integrator = NewsFeatureIntegrator(NEWS_API_KEY)
        df_features = news_integrator.add_psychology_features(df_features, kampe)

        rec = {
            # Basic encoding
            "hjemme_encoded": hold_map[hjem],
            "ude_encoded": hold_map[ude],
            "year": kamp_dato.year,
            "month": kamp_dato.month,
            "day": kamp_dato.day,
            
            # xG features
            "hjemme_xG_avg": xg_h["xG_avg"],
            "hjemme_xGA_avg": xg_h["xGA_avg"],
            "hjemme_xG_diff": xg_h["xG_diff"],
            "hjemme_xG_ratio": xg_h["xG_ratio"],
            "ude_xG_avg": xg_u["xG_avg"],
            "ude_xGA_avg": xg_u["xGA_avg"],
            "ude_xG_diff": xg_u["xG_diff"],
            "ude_xG_ratio": xg_u["xG_ratio"],
            
            # Form features
            "hjemme_last5_pts": h_form[0],
            "hjemme_last5_gf": h_form[1],
            "hjemme_last5_ga": h_form[2],
            "ude_last5_pts": u_form[0],
            "ude_last5_gf": u_form[1],
            "ude_last5_ga": u_form[2],
            
            # H2H features
            "h2h_home_wins": h2h[0],
            "h2h_away_wins": h2h[1],
            "h2h_draws": h2h[2],
            
            # Standings features
            "hjemme_position": s_h["position"],
            "ude_position": s_u["position"],
            "hjemme_points": s_h["points"],
            "ude_points": s_u["points"],
            "hjemme_gf": s_h["gf"],
            "hjemme_ga": s_h["ga"],
            "ude_gf": s_u["gf"],
            "ude_ga": s_u["ga"],
            
            # Basic differential features
            "form_diff": h_form[0] - u_form[0],
            "xg_diff": xg_h["xG_avg"] - xg_u["xG_avg"],
            "standing_diff": s_u["position"] - s_h["position"],
            "mål_diff_5": (h_form[1] - h_form[2]) - (u_form[1] - u_form[2]),
            "expected_ga_gap": xg_u["xGA_avg"] - xg_h["xGA_avg"],
            "elo_diff": elo_feats["elo_diff"],
            "elo_form_diff": elo_feats["elo_form_diff"],
            "elo_home_adv": elo_feats["elo_home_adv"],
            "momentum_home": h_form_7[0] - h_form_30[0],
            "momentum_away": u_form_7[0] - u_form_30[0],
            "bookmaker_spread": spread,
            
            # 🆕 NEW xG FORM FEATURES
            "xg_form_diff": xg_h["xG_avg"] - xg_u["xG_avg"],
            "xga_form_diff": xg_h["xGA_avg"] - xg_u["xGA_avg"],
            
            # 🆕 NEW ELO FORM FEATURES
            "elo_momentum_home": elo_feats["elo_home_today"] - elo_feats["elo_home_30d"],
            "elo_momentum_away": elo_feats["elo_away_today"] - elo_feats["elo_away_30d"],
            "elo_momentum_diff": (elo_feats["elo_home_today"] - elo_feats["elo_home_30d"]) - (elo_feats["elo_away_today"] - elo_feats["elo_away_30d"]),
            
            # 🆕 NEW STANDINGS FEATURES
            "standings_diff": s_u["position"] - s_h["position"],
            "points_diff": s_h["points"] - s_u["points"],
            "goals_for_diff": s_h["gf"] - s_u["gf"],
            "goals_against_diff": s_u["ga"] - s_h["ga"],
            
            # 🆕 NEW MOMENTUM FEATURES
            "momentum_diff": (h_form_7[0] - h_form_30[0]) - (u_form_7[0] - u_form_30[0]),
            "goals_momentum_home": (h_form_7[1] - h_form_7[2]) - (h_form_30[1] - h_form_30[2]),
            "goals_momentum_away": (u_form_7[1] - u_form_7[2]) - (u_form_30[1] - u_form_30[2]),
            "goals_momentum_diff": ((h_form_7[1] - h_form_7[2]) - (h_form_30[1] - h_form_30[2])) - ((u_form_7[1] - u_form_7[2]) - (u_form_30[1] - u_form_30[2])),
            
            # 🆕 NEW COMPOSITE FEATURES
            "overall_strength_diff": (s_h["points"] + xg_h["xG_avg"]*10 + elo_feats["elo_home_today"]/100) - 
                                   (s_u["points"] + xg_u["xG_avg"]*10 + elo_feats["elo_away_today"]/100),
            "form_quality_diff": (h_form[0] + (h_form[1]-h_form[2])) - (u_form[0] + (u_form[1]-u_form[2])),
            "elo_standings_correlation": (elo_feats["elo_home_today"] - elo_feats["elo_away_today"]) * (s_u["position"] - s_h["position"]),
            
            # 🌦️ NEW WEATHER FEATURES
            "weather_temperature": weather_features["weather_temperature"],
            "weather_wind": weather_features["weather_wind"], 
            "weather_rain": weather_features["weather_rain"],
            "weather_humidity": weather_features["weather_humidity"],
            "weather_visibility": weather_features["weather_visibility"],
            "weather_poor_conditions": weather_features["weather_poor_conditions"],
            "weather_extreme": weather_features["weather_extreme"]


        }

        records.append(rec)

    df_features = pd.DataFrame(records)
    
    # Ensure all expected columns exist with proper ordering
    expected_columns = [
        "hjemme_encoded", "ude_encoded", "year", "month", "day",
        "hjemme_last5_pts", "hjemme_last5_gf", "hjemme_last5_ga",
        "ude_last5_pts", "ude_last5_gf", "ude_last5_ga",
        "h2h_home_wins", "h2h_away_wins", "h2h_draws",
        "form_diff", "xg_diff", "expected_ga_gap", "standing_diff", "mål_diff_5",
        "elo_diff", "elo_form_diff", "momentum_home", "momentum_away", "bookmaker_spread",  # ← FIXED!
        # New features - exact same order as training
        "xg_form_diff", "xga_form_diff",
        "elo_form_diff", "elo_momentum_home", "elo_momentum_away", "elo_momentum_diff", 
        "standings_diff", "points_diff", "goals_for_diff", "goals_against_diff",
        "momentum_diff", "goals_momentum_home", "goals_momentum_away", "goals_momentum_diff",
        "overall_strength_diff", "form_quality_diff", "elo_standings_correlation",
        # 🌦️ Weather features
        "weather_temperature", "weather_wind", "weather_rain", "weather_humidity",
        "weather_visibility", "weather_poor_conditions", "weather_extreme"
        # NEWS API
        "sentiment_differential", "home_sentiment", "away_sentiment",
        "manager_pressure_differential", "home_manager_pressure", "away_manager_pressure", 
        "controversy_differential", "total_controversy",
        "injury_concern_differential", "news_attention_differential", "psychology_confidence"
    ]
    
    print(f"✅ Expected {len(expected_columns)} features")
    print(f"📊 Generated {len(df_features.columns)} features")
    
    # Add missing columns with default values
    for col in expected_columns:
        if col not in df_features.columns:
            df_features[col] = 0
            print(f"⚠️ Added missing column: {col}")
    
    # Ensure correct column order
    df_features = df_features[expected_columns]
    
    print(f"✅ Final feature set: {len(df_features.columns)} features in correct order")
    print(f"🌦️ Weather integration: {'ACTIVE' if WEATHER_API_KEY != 'YOUR_API_KEY_HERE' else 'INACTIVE (set API key)'}")
    
    return df_features