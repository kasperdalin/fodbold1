import requests
import json
import os

APP_KEY = "CQfr8ejzdQqJGyeo"
SESSION_TOKEN = "7DUJmcnzi75o0eyyW+3czHs2hQF2BYghv/UMDj+wizY="

HEADERS = {
    "X-Application": APP_KEY,
    "X-Authentication": SESSION_TOKEN,
    "Content-Type": "application/json"
}

API_ENDPOINT = "https://api.betfair.com/exchange/betting/json-rpc/v1"
SAVE_PATH = "data/betfair_odds.json"

def make_rpc_request(method, params):
    payload = [{
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1
    }]
    response = requests.post(API_ENDPOINT, json=payload, headers=HEADERS)
    response.raise_for_status()
    result = response.json()
    if "error" in result[0]:
        raise Exception(f"API Error: {result[0]['error']}")
    return result[0]["result"]

def list_event_types():
    return make_rpc_request("SportsAPING/v1.0/listEventTypes", {"filter": {}})

def list_market_catalogue(event_type_ids, max_results=10):
    params = {
        "filter": {
            "eventTypeIds": event_type_ids,
            "marketTypeCodes": ["MATCH_ODDS"]
        },
        "sort": "FIRST_TO_START",
        "maxResults": max_results,
        "marketProjection": ["MARKET_START_TIME", "RUNNER_DESCRIPTION", "COMPETITION", "EVENT"]
    }
    return make_rpc_request("SportsAPING/v1.0/listMarketCatalogue", params)

def list_market_book(market_ids):
    params = {
        "marketIds": market_ids,
        "priceProjection": {
            "priceData": ["EX_BEST_OFFERS"]
        }
    }
    return make_rpc_request("SportsAPING/v1.0/listMarketBook", params)

def hent_og_gem_odds():
    event_types = list_event_types()
    football_id = next((e["eventType"]["id"] for e in event_types if e["eventType"]["name"].lower() == "soccer"), None)
    if not football_id:
        raise Exception("Kunne ikke finde Soccer event type ID.")

    markets = list_market_catalogue([football_id], max_results=20)
    market_ids = [m["marketId"] for m in markets]
    market_books = list_market_book(market_ids)

    alle_kampe = []

    for market, book in zip(markets, market_books):
        event = market["event"]
        runners = book.get("runners", [])
        runner_map = {r["selectionId"]: r["runnerName"] for r in market["runners"]}
        odds = {}

        for runner in runners:
            selection_id = runner["selectionId"]
            name = runner_map.get(selection_id)
            if not name:
                continue  # spring "Ukendt" over

            prices = runner.get("ex", {}).get("availableToBack", [])
            if prices:
                best_price = prices[0]["price"]
                odds[name] = best_price

        if not odds:
            continue  # spring kamp over hvis ingen odds

        kamp = {
            "home_team": event["name"].split(" v ")[0].strip(),
            "away_team": event["name"].split(" v ")[1].strip() if " v " in event["name"] else "Ukendt",
            "start_time": event["openDate"],
            "odds": odds
        }
        alle_kampe.append(kamp)

    os.makedirs("data", exist_ok=True)
    with open(SAVE_PATH, "w", encoding="utf-8") as f:
        json.dump(alle_kampe, f, indent=2)
    print(f"✅ Gemte {len(alle_kampe)} kampe med odds i {SAVE_PATH}")

if __name__ == "__main__":
    try:
        print("▶️ Henter og viser kommende fodboldkampe med odds")
        event_types = list_event_types()
        football_id = next((e["eventType"]["id"] for e in event_types if e["eventType"]["name"].lower() == "soccer"), None)

        if not football_id:
            print("❌ Kunne ikke finde Soccer event type")
            exit(1)

        print(f"\n✅ Soccer event type ID: {football_id}")

        markets = list_market_catalogue([football_id], max_results=5)
        market_ids = [m["marketId"] for m in markets]
        market_books = list_market_book(market_ids)

        print("\n🎯 Kommende fodboldkampe med odds:")
        for market, book in zip(markets, market_books):
            event = market["event"]
            start = market["marketStartTime"]
            market_name = market["marketName"]
            runners = book.get("runners", [])
            runner_map = {r["selectionId"]: r["runnerName"] for r in market["runners"]}

            print(f"\n⚽ {event['name']} | Start: {start}")
            print("  Market:", market_name)
            for runner in runners:
                name = runner_map.get(runner["selectionId"])
                prices = runner.get("ex", {}).get("availableToBack", [])
                if name and prices:
                    print(f"  🔹 {name}: {prices[0]['price']}")
                elif name:
                    print(f"  🔹 {name}: Ingen odds")

        hent_og_gem_odds()

    except Exception as e:
        print(f"[FEJL] {e}")
