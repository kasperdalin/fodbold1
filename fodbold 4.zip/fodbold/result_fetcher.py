import requests
import pandas as pd
from datetime import datetime
import time

API_KEY = "3ea7581f7fa34b1fbb5d58ffc46a5821"  # din Football-Data API-nøgle
BASE_URL = "https://api.football-data.org/v4"
HEADERS = {"X-Auth-Token": API_KEY}

LIGAER = ["PL", "PD", "SA", "BL1", "FL1"]  # England, Spanien, Italien, Tyskland, Frankrig
LOG_PATH = "data/betting_log.csv"

def hent_alle_kampe():
    alle_kampe = []
    for liga in LIGAER:
        url = f"{BASE_URL}/competitions/{liga}/matches?season=2024"
        print(f"🔄 Henter kampe fra {liga}...")
        try:
            r = requests.get(url, headers=HEADERS)
            r.raise_for_status()
            alle_kampe.extend(r.json()["matches"])
            time.sleep(1)  # undgå rate limit
        except Exception as e:
            print(f"❌ Fejl ved {liga}: {e}")
    return alle_kampe

def kampresultat(match):
    if match["score"]["winner"] == "HOME_TEAM":
        return "1"
    elif match["score"]["winner"] == "AWAY_TEAM":
        return "2"
    elif match["score"]["winner"] == "DRAW":
        return "X"
    return ""

def match_kamp(row, kampe):
    hjem = row["kamp"].split(" vs ")[0].strip().lower()
    ude = row["kamp"].split(" vs ")[1].strip().lower()
    kamp_dato = row["dato"][:10]

    for match in kampe:
        match_date = match["utcDate"][:10]
        m_home = match["homeTeam"]["name"].strip().lower()
        m_away = match["awayTeam"]["name"].strip().lower()

        if (hjem in m_home and ude in m_away) or (hjem in m_home and ude in m_away):
            if kamp_dato == match_date and match["status"] == "FINISHED":
                return kampresultat(match)
    return ""

def opdater_betting_log():
    try:
        df = pd.read_csv(LOG_PATH)
    except FileNotFoundError:
        print("❌ betting_log.csv ikke fundet.")
        return

    print("📥 Indlæser kampe fra Football-Data...")
    kampe = hent_alle_kampe()

    print("🔍 Matcher kampe og finder resultater...")
    df["actual_result"] = df.apply(lambda row: match_kamp(row, kampe), axis=1)

    df.to_csv(LOG_PATH, index=False)
    print("✅ Opdateret betting_log.csv med actual_result")

if __name__ == "__main__":
    opdater_betting_log()
