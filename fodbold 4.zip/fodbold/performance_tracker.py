import pandas as pd

LOG_PATH = "data/betting_log.csv"

def performance_tracker():
    try:
        df = pd.read_csv(LOG_PATH)
    except FileNotFoundError:
        print("❌ betting_log.csv ikke fundet.")
        return

    # Simuleret resultater: Tilføj denne kolonne i test (1, X, 2)
    if "actual_result" not in df.columns:
        print("⚠️ Kolonnen 'actual_result' mangler i log. Tilføj for præcis analyse.")
        return

    # Filtrer kun færdigspillede value bets med gyldigt resultat
    value_df = df[(df["value_bet"] != "Ingen") & (df["actual_result"].isin(["1", "2", "X"]))].copy()


    if value_df.empty:
        print("⚠️ Ingen value bets fundet i log.")
        return

    # Konverter resultater til str for sammenligning
    value_df["prediction"] = value_df["prediction"].astype(str)
    value_df["actual_result"] = value_df["actual_result"].astype(str)

    # Hit rate
    hits = (value_df["prediction"] == value_df["actual_result"]).sum()
    total = len(value_df)
    hitrate = hits / total * 100

    # Profitberegning
    profit = 0
    for _, row in value_df.iterrows():
        pred = row["value_bet"]
        actual = row["actual_result"]
        odds = {
            "1": row["odds_1"],
            "X": row["odds_X"],
            "2": row["odds_2"]
        }.get(str(pred), 0)

        if str(pred) == str(actual):
            profit += odds - 1  # gevinst
        else:
            profit -= 1  # tab

    roi = (profit / total) * 100

    print("\n📊 PERFORMANCE RAPPORT")
    print(f"🔢 Antal value bets: {total}")
    print(f"✅ Korrekte value bets: {hits}")
    print(f"🎯 Hitrate: {hitrate:.2f}%")
    print(f"💰 Total profit: {profit:.2f} units")
    print(f"📈 ROI: {roi:.2f}%")

if __name__ == "__main__":
    performance_tracker()
