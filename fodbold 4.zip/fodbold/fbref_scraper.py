import requests
import pandas as pd
import json
import time
import os
from bs4 import BeautifulSoup
from datetime import datetime
import numpy as np

class FBrefScraper:
    def __init__(self):
        self.base_url = "https://fbref.com"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        })
        
        # 🌍 ALLE 5 STORE LIGAER
        self.leagues = {
            "Premier_League": {
                "comp_id": "9",
                "name": "Premier League",
                "url_name": "Premier-League-Stats"
            },
            "La_Liga": {
                "comp_id": "12", 
                "name": "La Liga",
                "url_name": "La-Liga-Stats"
            },
            "Bundesliga": {
                "comp_id": "20",
                "name": "Bundesliga", 
                "url_name": "Bundesliga-Stats"
            },
            "Serie_A": {
                "comp_id": "11",
                "name": "Serie A",
                "url_name": "Serie-A-Stats"
            },
            "Ligue_1": {
                "comp_id": "13",
                "name": "Ligue 1",
                "url_name": "Ligue-1-Stats"
            }
        }
        
    def scrape_league_team_stats(self, league_key, season="2024-2025"):
        """Scraper hold statistikker for en specifik liga"""
        
        league_info = self.leagues.get(league_key)
        if not league_info:
            print(f"❌ Unknown league: {league_key}")
            return pd.DataFrame()
        
        print(f"🔍 Scraper {league_info['name']} {season} hold stats...")
        
        # Liga URL
        url = f"{self.base_url}/en/comps/{league_info['comp_id']}/{league_info['url_name']}"
        
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find ALL tables and debug
            all_tables = soup.find_all('table')
            print(f"🔍 Found {len(all_tables)} tables on {league_info['name']} page")
            
            # Look for table with team data (try multiple selectors)
            table = None
            for t in all_tables:
                table_id = t.get('id', '')
                if any(keyword in table_id.lower() for keyword in ['squad', 'team', 'stats']):
                    print(f"✅ Found potential table: {table_id}")
                    table = t
                    break
            
            # If no ID match, try first table with data
            if not table and all_tables:
                table = all_tables[0]
                print("⚠️ Using first table as fallback")
            
            if not table:
                print(f"❌ No suitable table found for {league_info['name']}")
                return pd.DataFrame()
            
            # Extract headers (handle multiple header rows)
            headers = []
            thead = table.find('thead')
            if thead:
                header_rows = thead.find_all('tr')
                # Use last header row for most specific column names
                last_header_row = header_rows[-1] if header_rows else None
                if last_header_row:
                    for th in last_header_row.find_all(['th', 'td']):
                        header_text = th.get_text(strip=True)
                        if not header_text:
                            header_text = f"col_{len(headers)}"
                        headers.append(header_text)
            
            print(f"📋 Extracted {len(headers)} headers for {league_info['name']}")
            
            # Extract data rows
            rows = []
            tbody = table.find('tbody')
            if tbody:
                for tr in tbody.find_all('tr'):
                    # Skip header rows in tbody
                    if tr.get('class') and 'thead' in tr.get('class'):
                        continue
                        
                    row_data = []
                    cells = tr.find_all(['td', 'th'])
                    for cell in cells:
                        text = cell.get_text(strip=True)
                        row_data.append(text)
                    
                    # Only add rows with substantial data
                    if len(row_data) >= 3 and any(cell for cell in row_data[1:3]):
                        rows.append(row_data)
            
            print(f"📊 Extracted {len(rows)} data rows for {league_info['name']}")
            
            if not rows:
                print(f"❌ No data rows found for {league_info['name']}")
                return pd.DataFrame()
            
            # Handle column mismatch
            max_cols = max(len(row) for row in rows) if rows else 0
            min_cols = min(len(row) for row in rows) if rows else 0
            
            print(f"🔍 {league_info['name']} row lengths: min={min_cols}, max={max_cols}, headers={len(headers)}")
            
            # Pad headers if needed
            while len(headers) < max_cols:
                headers.append(f"col_{len(headers)}")
            
            # Pad rows if needed
            for i, row in enumerate(rows):
                while len(row) < max_cols:
                    row.append("")
                # Truncate if too long
                rows[i] = row[:max_cols]
            
            # Create DataFrame with correct number of columns
            df = pd.DataFrame(rows, columns=headers[:max_cols])
            
            # Add league info
            df['League'] = league_info['name']
            df['League_Key'] = league_key
            
            print(f"✅ Created {league_info['name']} DataFrame: {df.shape}")
            return df
            
        except Exception as e:
            print(f"❌ Error scraping {league_info['name']} team stats: {e}")
            return pd.DataFrame()
    
    def scrape_all_leagues_team_stats(self):
        """Scraper alle 5 store ligaer"""
        print("🌍 Scraping ALL BIG 5 LEAGUES...")
        
        all_leagues_data = {}
        
        for league_key in self.leagues.keys():
            print(f"\n🔄 Processing {self.leagues[league_key]['name']}...")
            
            df = self.scrape_league_team_stats(league_key)
            if not df.empty:
                all_leagues_data[league_key] = df
                time.sleep(2)  # Respectful delay between requests
            else:
                print(f"⚠️ No data for {self.leagues[league_key]['name']}")
        
        print(f"\n✅ Successfully scraped {len(all_leagues_data)} leagues!")
        return all_leagues_data
        """Scraper Premier League hold statistikker"""
        
        print(f"🔍 Scraper Premier League {season} hold stats...")
        
        # Premier League URL
        url = f"{self.base_url}/en/comps/9/Premier-League-Stats"
        
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find ALL tables and debug
            all_tables = soup.find_all('table')
            print(f"🔍 Found {len(all_tables)} tables on page")
            
            # Look for table with team data (try multiple selectors)
            table = None
            for t in all_tables:
                table_id = t.get('id', '')
                if any(keyword in table_id.lower() for keyword in ['squad', 'team', 'stats']):
                    print(f"✅ Found potential table: {table_id}")
                    table = t
                    break
            
            # If no ID match, try first table with data
            if not table and all_tables:
                table = all_tables[0]
                print("⚠️ Using first table as fallback")
            
            if not table:
                print("❌ No suitable table found")
                return pd.DataFrame()
            
            # Extract headers (handle multiple header rows)
            headers = []
            thead = table.find('thead')
            if thead:
                header_rows = thead.find_all('tr')
                # Use last header row for most specific column names
                last_header_row = header_rows[-1] if header_rows else None
                if last_header_row:
                    for th in last_header_row.find_all(['th', 'td']):
                        header_text = th.get_text(strip=True)
                        if not header_text:
                            header_text = f"col_{len(headers)}"
                        headers.append(header_text)
            
            print(f"📋 Extracted {len(headers)} headers: {headers[:10]}...")
            
            # Extract data rows
            rows = []
            tbody = table.find('tbody')
            if tbody:
                for tr in tbody.find_all('tr'):
                    # Skip header rows in tbody
                    if tr.get('class') and 'thead' in tr.get('class'):
                        continue
                        
                    row_data = []
                    cells = tr.find_all(['td', 'th'])
                    for cell in cells:
                        text = cell.get_text(strip=True)
                        row_data.append(text)
                    
                    # Only add rows with substantial data
                    if len(row_data) >= 3 and any(cell for cell in row_data[1:3]):
                        rows.append(row_data)
            
            print(f"📊 Extracted {len(rows)} data rows")
            
            if not rows:
                print("❌ No data rows found")
                return pd.DataFrame()
            
            # Handle column mismatch
            max_cols = max(len(row) for row in rows) if rows else 0
            min_cols = min(len(row) for row in rows) if rows else 0
            
            print(f"🔍 Row lengths: min={min_cols}, max={max_cols}, headers={len(headers)}")
            
            # Pad headers if needed
            while len(headers) < max_cols:
                headers.append(f"col_{len(headers)}")
            
            # Pad rows if needed
            for i, row in enumerate(rows):
                while len(row) < max_cols:
                    row.append("")
                # Truncate if too long
                rows[i] = row[:max_cols]
            
            # Create DataFrame with correct number of columns
            df = pd.DataFrame(rows, columns=headers[:max_cols])
            
            print(f"✅ Created DataFrame: {df.shape}")
            return df
            
        except Exception as e:
            print(f"❌ Error scraping team stats: {e}")
            import traceback
            traceback.print_exc()
            return pd.DataFrame()
    
    def scrape_premier_league_player_stats(self, stat_type="standard"):
        """Scraper Premier League spiller statistikker"""
        
        print(f"🔍 Scraper Premier League player {stat_type} stats...")
        
        # Map stat types to URLs
        stat_urls = {
            "standard": f"{self.base_url}/en/comps/9/stats/Premier-League-Stats",
            "shooting": f"{self.base_url}/en/comps/9/shooting/Premier-League-Stats", 
            "passing": f"{self.base_url}/en/comps/9/passing/Premier-League-Stats",
            "defense": f"{self.base_url}/en/comps/9/defense/Premier-League-Stats",
            "possession": f"{self.base_url}/en/comps/9/possession/Premier-League-Stats",
            "playing_time": f"{self.base_url}/en/comps/9/playingtime/Premier-League-Stats",
            "gca": f"{self.base_url}/en/comps/9/gca/Premier-League-Stats",
            "misc": f"{self.base_url}/en/comps/9/misc/Premier-League-Stats"
        }
        
        url = stat_urls.get(stat_type, stat_urls["standard"])
        
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find ALL tables and debug
            all_tables = soup.find_all('table')
            print(f"🔍 Found {len(all_tables)} tables on player stats page")
            
            # Look for player stats table
            table = None
            for t in all_tables:
                table_id = t.get('id', '')
                print(f"🔍 Table ID: {table_id}")
                if 'stats' in table_id.lower() and 'player' in table_id.lower():
                    table = t
                    break
                elif 'stats' in table_id.lower():
                    table = t  # Fallback
            
            # Try finding by common patterns
            if not table:
                for t in all_tables:
                    # Check if table has player-like data
                    tbody = t.find('tbody')
                    if tbody:
                        first_row = tbody.find('tr')
                        if first_row:
                            cells = first_row.find_all(['td', 'th'])
                            if len(cells) > 10:  # Player tables usually have many columns
                                table = t
                                print("✅ Found table with many columns (likely players)")
                                break
            
            if not table:
                print(f"❌ Could not find player stats table for {stat_type}")
                return pd.DataFrame()
            
            # Extract headers (handle multi-level headers)
            headers = []
            thead = table.find('thead')
            
            if thead:
                header_rows = thead.find_all('tr')
                print(f"🔍 Found {len(header_rows)} header rows")
                
                # Use the last header row (most specific)
                if header_rows:
                    last_row = header_rows[-1]
                    for th in last_row.find_all(['th', 'td']):
                        header_text = th.get_text(strip=True)
                        # Clean up header names
                        header_text = header_text.replace('\n', '_').replace(' ', '_')
                        if not header_text:
                            header_text = f"col_{len(headers)}"
                        headers.append(header_text)
            
            print(f"📋 Extracted {len(headers)} player headers")
            
            # Extract player data
            rows = []
            tbody = table.find('tbody')
            if tbody:
                for tr in tbody.find_all('tr'):
                    if tr.get('class') and 'thead' in tr.get('class'):
                        continue
                        
                    row_data = []
                    for td in tr.find_all(['td', 'th']):
                        text = td.get_text(strip=True)
                        # Convert numeric values
                        try:
                            if text and text.replace('.', '').replace('-', '').replace('+', '').isdigit():
                                text = float(text) if '.' in text else int(text)
                        except:
                            pass
                        row_data.append(text)
                    
                    if len(row_data) > 3:  # Skip rows with too little data
                        rows.append(row_data)
            
            print(f"📊 Extracted {len(rows)} player rows")
            
            if not rows:
                return pd.DataFrame()
            
            # Handle column mismatch
            max_cols = max(len(row) for row in rows)
            
            # Pad headers if needed
            while len(headers) < max_cols:
                headers.append(f"col_{len(headers)}")
            
            # Pad rows if needed
            for i, row in enumerate(rows):
                while len(row) < max_cols:
                    row.append("")
                rows[i] = row[:max_cols]
            
            # Create DataFrame
            df = pd.DataFrame(rows, columns=headers[:max_cols])
            
            print(f"✅ Scraped {len(df)} players with {len(df.columns)} {stat_type} stats")
            return df
            
        except Exception as e:
            print(f"❌ Error scraping player {stat_type} stats: {e}")
            import traceback
            traceback.print_exc()
            return pd.DataFrame()
    
    def get_team_xg_advanced_stats(self):
        """Hent avancerede xG statistikker for alle hold"""
        
        print("📊 Henter avancerede xG stats...")
        
        try:
            # Team shooting stats
            shooting_df = self.scrape_premier_league_team_stats_advanced("shooting")
            
            # Team defensive stats  
            defense_df = self.scrape_premier_league_team_stats_advanced("defense")
            
            # Combine data
            team_stats = {}
            
            if not shooting_df.empty:
                for _, row in shooting_df.iterrows():
                    team = row.get('Squad', '')
                    if team:
                        team_stats[team] = {
                            'xG_per_90': row.get('xG', 0) / max(row.get('90s', 1), 1),
                            'xG_per_shot': row.get('xG', 0) / max(row.get('Sh', 1), 1),
                            'shots_per_90': row.get('Sh', 0) / max(row.get('90s', 1), 1),
                            'shots_on_target_pct': row.get('SoT%', 0)
                        }
            
            if not defense_df.empty:
                for _, row in defense_df.iterrows():
                    team = row.get('Squad', '')
                    if team in team_stats:
                        team_stats[team].update({
                            'tackles_per_90': row.get('Tkl', 0) / max(row.get('90s', 1), 1),
                            'interceptions_per_90': row.get('Int', 0) / max(row.get('90s', 1), 1),
                            'blocks_per_90': row.get('Blocks', 0) / max(row.get('90s', 1), 1)
                        })
            
            print(f"✅ Compiled advanced stats for {len(team_stats)} teams")
            return team_stats
            
        except Exception as e:
            print(f"❌ Error getting advanced team stats: {e}")
            return {}
    
    def scrape_premier_league_team_stats_advanced(self, stat_type):
        """Helper function for advanced team stats"""
        
        stat_urls = {
            "shooting": f"{self.base_url}/en/comps/9/shooting/Premier-League-Stats",
            "defense": f"{self.base_url}/en/comps/9/defense/Premier-League-Stats",
            "possession": f"{self.base_url}/en/comps/9/possession/Premier-League-Stats"
        }
        
        url = stat_urls.get(stat_type)
        if not url:
            return pd.DataFrame()
        
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            tables = soup.find_all('table')
            
            # Find the squad stats table (usually first one)
            for table in tables:
                if 'squad' in table.get('id', '').lower():
                    # Parse table
                    headers = []
                    tbody = table.find('tbody')
                    if not tbody:
                        continue
                        
                    # Get headers
                    thead = table.find('thead')
                    if thead:
                        for th in thead.find_all('th')[-20:]:  # Take last row of headers
                            headers.append(th.get_text(strip=True))
                    
                    # Get data
                    rows = []
                    for tr in tbody.find_all('tr'):
                        row_data = []
                        for td in tr.find_all(['td', 'th']):
                            text = td.get_text(strip=True)
                            # Try to convert to numbers
                            try:
                                if text and '.' in text:
                                    text = float(text)
                                elif text and text.isdigit():
                                    text = int(text)
                            except:
                                pass
                            row_data.append(text)
                        
                        if len(row_data) > 3:
                            rows.append(row_data)
                    
                    df = pd.DataFrame(rows, columns=headers[:len(rows[0])] if rows else headers)
                    return df
            
            return pd.DataFrame()
            
        except Exception as e:
            print(f"❌ Error in advanced scraping: {e}")
            return pd.DataFrame()
    
    def save_fbref_data(self):
        """Gem alle FBref data til JSON filer"""
        
        print("💾 Gemmer FBref data for ALL LEAGUES...")
        
        try:
            os.makedirs("data", exist_ok=True)
            
            # 1. Scrape all leagues
            all_leagues_data = self.scrape_all_leagues_team_stats()
            
            if not all_leagues_data:
                print("❌ No data scraped from any league")
                return False
            
            # 2. Process and save each league
            all_team_stats = {}
            
            for league_key, df in all_leagues_data.items():
                league_name = self.leagues[league_key]['name']
                print(f"\n📊 Processing {league_name}...")
                
                league_teams = {}
                
                for idx, row in df.iterrows():
                    # Convert row to dict properly 
                    row_dict = row.to_dict() if hasattr(row, 'to_dict') else dict(row)
                    
                    team = row_dict.get('Squad', '')
                    if team:
                        # Extract key stats with safe conversion
                        def safe_convert(value, default=0):
                            try:
                                if pd.isna(value) or value == '' or value == '-':
                                    return default
                                # Remove any non-numeric characters except . and -
                                cleaned = str(value).replace(',', '').strip()
                                return float(cleaned) if '.' in cleaned else int(cleaned)
                            except:
                                return default
                        
                        league_teams[team] = {
                            'league': league_name,
                            'league_key': league_key,
                            'points': safe_convert(row_dict.get('Pts', 0)),
                            'position': safe_convert(row_dict.get('Rk', 0)),
                            'wins': safe_convert(row_dict.get('W', 0)),
                            'draws': safe_convert(row_dict.get('D', 0)),
                            'losses': safe_convert(row_dict.get('L', 0)),
                            'goals_for': safe_convert(row_dict.get('GF', 0)),
                            'goals_against': safe_convert(row_dict.get('GA', 0)),
                            'xG': safe_convert(row_dict.get('xG', 0)),
                            'xGA': safe_convert(row_dict.get('xGA', 0)),
                            'matches_played': safe_convert(row_dict.get('MP', 0)),
                            'minutes': safe_convert(row_dict.get('Min', 0)),
                            'goals': safe_convert(row_dict.get('Gls', 0)),
                            'assists': safe_convert(row_dict.get('Ast', 0)),
                            'possession': safe_convert(row_dict.get('Poss', 0))
                        }
                
                all_team_stats.update(league_teams)
                print(f"✅ Processed {len(league_teams)} teams from {league_name}")
            
            # 3. Save combined data
            with open("data/fbref_all_leagues_stats.json", "w", encoding="utf-8") as f:
                json.dump(all_team_stats, f, ensure_ascii=False, indent=2)
            print(f"\n✅ Saved combined stats for {len(all_team_stats)} teams across all leagues")
            
            # 4. Save league-specific files
            for league_key, df in all_leagues_data.items():
                league_name = self.leagues[league_key]['name'].replace(' ', '_').lower()
                df.to_csv(f"data/fbref_{league_name}_stats.csv", index=False)
                print(f"✅ Saved {league_name} CSV with {len(df)} teams")
            
            # 5. Create league summary
            league_summary = {}
            for league_key, league_info in self.leagues.items():
                teams_count = len([t for t in all_team_stats.values() if t['league_key'] == league_key])
                league_summary[league_key] = {
                    'name': league_info['name'],
                    'teams_scraped': teams_count,
                    'comp_id': league_info['comp_id']
                }
            
            with open("data/fbref_league_summary.json", "w", encoding="utf-8") as f:
                json.dump(league_summary, f, ensure_ascii=False, indent=2)
            
            print("\n🎉 ALL LEAGUES FBref data successfully saved!")
            print(f"📊 Total: {len(all_team_stats)} teams from {len(all_leagues_data)} leagues")
            
            return True
            
        except Exception as e:
            print(f"❌ Error saving FBref data: {e}")
            import traceback
            traceback.print_exc()
            return False

def main():
    """Test multi-league FBref scraper"""
    scraper = FBrefScraper()
    
    print("🌍 Starting BIG 5 LEAGUES FBref data collection...")
    print("Leagues: Premier League, La Liga, Bundesliga, Serie A, Ligue 1")
    
    # Test individual league
    print("\n🔍 Testing Premier League...")
    epl_df = scraper.scrape_league_team_stats("Premier_League")
    print(f"Premier League: {epl_df.shape}")
    
    # Test all leagues
    print("\n🌍 Testing all leagues...")
    all_data = scraper.scrape_all_leagues_team_stats()
    print(f"Total leagues scraped: {len(all_data)}")
    
    # Save all data
    print("\n💾 Saving all data...")
    success = scraper.save_fbref_data()
    
    if success:
        print("\n✅ Multi-league FBref integration ready!")
        print("Files created:")
        print("  - data/fbref_all_leagues_stats.json (combined)")
        print("  - data/fbref_premier_league_stats.csv")
        print("  - data/fbref_la_liga_stats.csv") 
        print("  - data/fbref_bundesliga_stats.csv")
        print("  - data/fbref_serie_a_stats.csv")
        print("  - data/fbref_ligue_1_stats.csv")
        print("  - data/fbref_league_summary.json")
        print("\nNext: Update featurizer.py to use multi-league FBref data")
    else:
        print("\n❌ Multi-league FBref integration failed")

if __name__ == "__main__":
    main()