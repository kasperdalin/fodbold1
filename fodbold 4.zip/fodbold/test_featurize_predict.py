from featurize_predict import featurize_kommende_kampe

kommende_kampe = [
    {
        "hjemme": "Manchester City",
        "ude": "Arsenal",
        "dato": "2025-06-01T15:00:00Z"
    }
]

df = featurize_kommende_kampe(kommende_kampe)
print("\n✅ Forudsagt features for testkamp:")
print(df.T)  # Transponér for bedre overblik