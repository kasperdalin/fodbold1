import pandas as pd
import xgboost as xgb
import joblib
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, roc_auc_score
from featurizer import featurize

# === 1. Indlæs data og features ===
df = pd.read_csv("data/kampe_clean.csv", parse_dates=["dato"])
X, y = featurize(df)

# === 2. Split data (uden shuffle) ===
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

# === 3. Definér model og param grid ===
model = xgb.XGBClassifier(
    objective="multi:softprob",
    eval_metric="mlogloss",
    use_label_encoder=False,
    n_jobs=-1
)

param_grid = {
    "n_estimators": [100, 250],
    "max_depth": [3, 5, 7],
    "learning_rate": [0.01, 0.05, 0.1],
    "subsample": [0.7, 0.9],
    "colsample_bytree": [0.7, 0.9]
}

# === 4. Grid search ===
print("🔍 Starter hyperparameter tuning...\n")
grid = GridSearchCV(
    estimator=model,
    param_grid=param_grid,
    scoring="roc_auc_ovr",
    cv=3,
    verbose=1,
    n_jobs=-1
)

grid.fit(X_train, y_train)

# === 5. Evaluer bedste model ===
best_model = grid.best_estimator_
y_pred = best_model.predict(X_test)
y_prob = best_model.predict_proba(X_test)

acc = accuracy_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob, multi_class='ovr')

print("\n✅ Bedste parametre fundet:")
print(grid.best_params_)
print(f"\n🎯 Accuracy (test): {acc:.3f}")
print(f"📈 AUC (test): {auc:.3f}")

# === 6. Gem model ===
joblib.dump(best_model, "models/xgb_best.pkl")
print("💾 Gemte tunet model til models/xgb_best.pkl")
