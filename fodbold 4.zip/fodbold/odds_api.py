import requests
import json
import os
from datetime import datetime, timedelta

API_KEY = "1811e6d89e8e7e5c0425f62edabc32a6"  # Your API key
BASE_URL = "https://api.the-odds-api.com/v4/sports"
REGION = "eu"
MARKET = "h2h"

LEAGUES = [
    "soccer_epl",
    "soccer_spain_la_liga", 
    "soccer_germany_bundesliga",
    "soccer_italy_serie_a",
    "soccer_france_ligue_one"
]

SAVE_PATH = "data/odds_data.json"

def test_api_connection():
    """Test if API key works"""
    url = f"{BASE_URL}"
    params = {"apiKey": API_KEY}
    
    try:
        response = requests.get(url, params=params)
        print(f"🔍 API Status Code: {response.status_code}")
        
        if response.status_code == 200:
            sports = response.json()
            print(f"✅ API Working! Found {len(sports)} sports")
            return True
        elif response.status_code == 401:
            print("❌ API Key Invalid or Expired")
            return False
        elif response.status_code == 429:
            print("⚠️ API Rate Limit Exceeded")
            return False
        else:
            print(f"❌ API Error: {response.status_code}")
            print(response.text)
            return False
            
    except Exception as e:
        print(f"❌ Connection Error: {e}")
        return False

def hent_odds():
    # Test API first
    if not test_api_connection():
        print("🚫 Stopping - API not working")
        return []
    
    alle_odds = []
    total_requests = 0
    
    for league in LEAGUES:
        url = f"{BASE_URL}/{league}/odds"
        params = {
            "apiKey": API_KEY,
            "regions": REGION,
            "markets": MARKET,
            "oddsFormat": "decimal",
            "dateFormat": "iso"
        }

        try:
            print(f"\n🔄 Henter odds for {league}...")
            response = requests.get(url, params=params)
            total_requests += 1
            
            print(f"   Status: {response.status_code}")
            
            if response.status_code == 200:
                games = response.json()
                print(f"   Fundet: {len(games)} kampe")
                
                for game in games:
                    # Filter for upcoming games only (next 7 days)
                    game_time = datetime.fromisoformat(game["commence_time"].replace('Z', '+00:00'))
                    now = datetime.now(game_time.tzinfo)
                    
                    if game_time < now or game_time > now + timedelta(days=7):
                        continue  # Skip past games or games too far in future
                    
                    kamp = {
                        "league": league,
                        "home_team": game["home_team"],
                        "away_team": game["away_team"],
                        "commence_time": game["commence_time"],
                        "bookmakers": [],
                        "odds": {"1": None, "X": None, "2": None}
                    }

                    total_odds = {"1": [], "X": [], "2": []}
                    
                    for bookmaker in game.get("bookmakers", []):
                        bm = {
                            "title": bookmaker["title"],
                            "last_update": bookmaker["last_update"],
                            "odds": {"1": None, "X": None, "2": None}
                        }

                        for market in bookmaker.get("markets", []):
                            if market["key"] == "h2h":
                                for outcome in market["outcomes"]:
                                    name = outcome["name"]
                                    price = outcome["price"]
                                    
                                    if name == game["home_team"]:
                                        bm["odds"]["1"] = price
                                        total_odds["1"].append(price)
                                    elif name == game["away_team"]:
                                        bm["odds"]["2"] = price
                                        total_odds["2"].append(price)
                                    elif name.lower() == "draw":
                                        bm["odds"]["X"] = price
                                        total_odds["X"].append(price)

                        # Only add bookmaker if it has complete odds
                        if all(bm["odds"].values()):
                            kamp["bookmakers"].append(bm)

                    # Calculate average odds
                    kamp["odds"] = {
                        "1": round(sum(total_odds["1"]) / len(total_odds["1"]), 3) if total_odds["1"] else None,
                        "X": round(sum(total_odds["X"]) / len(total_odds["X"]), 3) if total_odds["X"] else None,
                        "2": round(sum(total_odds["2"]) / len(total_odds["2"]), 3) if total_odds["2"] else None
                    }

                    # Only add games with complete average odds
                    if all(kamp["odds"].values()) and kamp["bookmakers"]:
                        alle_odds.append(kamp)
                        print(f"   ✅ {kamp['home_team']} vs {kamp['away_team']}")

            elif response.status_code == 401:
                print("   ❌ API Key problem")
                break
            elif response.status_code == 429:
                print("   ⚠️ Rate limit exceeded")
                break
            else:
                print(f"   ❌ Error: {response.status_code}")
                print(f"   Response: {response.text[:200]}")

        except Exception as e:
            print(f"   ❌ Exception: {e}")

    print(f"\n📊 SUMMARY:")
    print(f"🔢 Total API requests: {total_requests}")
    print(f"⚽ Total games found: {len(alle_odds)}")
    
    # Save data
    os.makedirs("data", exist_ok=True)
    with open(SAVE_PATH, "w", encoding="utf-8") as f:
        json.dump(alle_odds, f, indent=2)
    print(f"💾 Saved to {SAVE_PATH}")
    
    return alle_odds

if __name__ == "__main__":
    print(f"🚀 Starting Odds API fetch at {datetime.now()}")
    odds = hent_odds()
    
    if odds:
        print(f"\n🎯 Sample game:")
        print(json.dumps(odds[0], indent=2))
    else:
        print("\n⚠️ No odds data retrieved. Check API key and quotas.")