import json
import os

def check_xg_data():
    """Check if xG data has proper team names"""
    print("🔍 Checking xG data...")
    
    if not os.path.exists("data/xg_stats.json"):
        print("❌ xg_stats.json not found")
        return False
        
    with open("data/xg_stats.json", "r", encoding="utf-8") as f:
        xg_data = json.load(f)
    
    # Check if we have team names instead of IDs
    sample_teams = ["Liverpool FC", "Manchester City FC", "Arsenal FC", "FC Barcelona"]
    found_teams = []
    
    for team in sample_teams:
        if team in xg_data:
            found_teams.append(team)
            stats = xg_data[team]
            print(f"✅ {team}: xG_avg={stats.get('xG_avg')}, xGA_avg={stats.get('xGA_avg')}")
    
    if found_teams:
        print(f"✅ xG data fixed! Found {len(found_teams)}/{len(sample_teams)} test teams")
        return True
    else:
        print("❌ xG data still uses IDs instead of team names")
        return False

def check_odds_data():
    """Check if odds data is populated"""
    print("\n🔍 Checking odds data...")
    
    if not os.path.exists("data/odds_data.json"):
        print("❌ odds_data.json not found")
        return False
        
    with open("data/odds_data.json", "r", encoding="utf-8") as f:
        odds_data = json.load(f)
    
    if not odds_data:
        print("❌ odds_data.json is empty")
        return False
    
    print(f"✅ Found {len(odds_data)} games with odds")
    
    # Show sample
    if odds_data:
        sample = odds_data[0]
        print(f"📊 Sample: {sample['home_team']} vs {sample['away_team']}")
        print(f"   Odds: 1={sample['odds']['1']}, X={sample['odds']['X']}, 2={sample['odds']['2']}")
        print(f"   Bookmakers: {len(sample['bookmakers'])}")
    
    return True

def test_feature_engineering():
    """Test if features work with fixed data"""
    print("\n🔍 Testing feature engineering...")
    
    try:
        from featurize_predict import featurize_kommende_kampe
        
        # Test with a sample game using exact team names from our data
        test_games = [{
            "hjemme": "Liverpool FC",
            "ude": "Arsenal FC", 
            "dato": "2025-06-01T15:00:00Z"
        }]
        
        print(f"🎯 Testing with: {test_games[0]['hjemme']} vs {test_games[0]['ude']}")
        
        df = featurize_kommende_kampe(test_games)
        
        if df.empty:
            print("❌ Feature engineering returned empty DataFrame")
            return False
            
        print(f"✅ Generated features: {len(df.columns)} columns")
        print(f"📊 Feature names: {list(df.columns)[:10]}...")  # Show first 10
        
        # Check key features
        features_to_check = ['xg_diff', 'elo_diff', 'bookmaker_spread']
        working_features = []
        
        for feature in features_to_check:
            if feature in df.columns:
                value = df[feature].iloc[0]
                if value is not None and value != 0:
                    working_features.append(feature)
                    print(f"✅ {feature}: {value}")
                else:
                    print(f"⚠️ {feature}: {value} (default/null)")
            else:
                print(f"❌ {feature}: missing from columns")
        
        # Show a few more features for debugging
        other_features = ['hjemme_xG_avg', 'ude_xG_avg', 'form_diff']
        for feature in other_features:
            if feature in df.columns:
                value = df[feature].iloc[0]
                print(f"📊 {feature}: {value}")
        
        print(f"✅ Feature engineering test completed: {len(working_features)}/{len(features_to_check)} key features working")
        return len(working_features) > 0
        
    except Exception as e:
        print(f"❌ Feature engineering test failed: {e}")
        import traceback
        print("📋 Full error trace:")
        print(traceback.format_exc())
        return False

if __name__ == "__main__":
    print("🔧 VERIFYING DATA FIXES\n")
    
    xg_ok = check_xg_data()
    odds_ok = check_odds_data() 
    features_ok = test_feature_engineering()
    
    print(f"\n📋 SUMMARY:")
    print(f"xG Data: {'✅' if xg_ok else '❌'}")
    print(f"Odds Data: {'✅' if odds_ok else '❌'}")
    print(f"Features: {'✅' if features_ok else '❌'}")
    
    if xg_ok and odds_ok and features_ok:
        print("\n🎉 ALL FIXES WORKING! Your system is ready! 🚀")
    else:
        print("\n⚠️ Some issues remain. Run the fix scripts first.")