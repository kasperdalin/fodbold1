from featurize_predict import featurize_kommende_kampe

# Test med mock kampe
test_kampe = [
    {
        "hjemme": "Arsenal FC",
        "ude": "Liverpool FC", 
        "dato": "2025-06-15T15:00:00Z"
    },
    {
        "hjemme": "Real Madrid CF",
        "ude": "FC Barcelona",
        "dato": "2025-06-16T20:00:00Z"  
    }
]

print("🧪 Testing Weather Integration...")
print("=" * 50)

try:
    # Test featurization med weather
    df = featurize_kommende_kampe(test_kampe)
    
    print(f"\n✅ SUCCESS! Generated {len(df.columns)} features")
    print(f"📊 Total rows: {len(df)}")
    
    # Show weather columns specifically
    weather_cols = [col for col in df.columns if 'weather' in col]
    print(f"\n🌦️ Weather columns ({len(weather_cols)}):")
    for col in weather_cols:
        print(f"  - {col}")
    
    # Show weather values for first game
    print(f"\n🌦️ Weather values for {test_kampe[0]['hjemme']} vs {test_kampe[0]['ude']}:")
    for col in weather_cols:
        value = df[col].iloc[0]
        print(f"  {col}: {value}")
    
    # Show sample of all features
    print(f"\n📊 All feature columns:")
    for i, col in enumerate(df.columns):
        print(f"  {i+1:2d}. {col}")
        
    # Quick data quality check
    print(f"\n🔍 Data Quality Check:")
    print(f"  - Any null values? {df.isnull().sum().sum()}")
    print(f"  - Any infinite values? {(df == float('inf')).sum().sum()}")
    
    print(f"\n🎉 Weather integration TEST PASSED!")
    
except Exception as e:
    print(f"❌ ERROR: {e}")
    import traceback
    print("\n📋 Full error trace:")
    print(traceback.format_exc())