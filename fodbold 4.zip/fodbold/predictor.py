import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import os

MODEL_PATH = "models/rf_model.pkl"

# Ekstremt simpel encoding baseret på holdnavne
# I en rigtig model skal dette erstattes med holdform, stats, elo-rating osv.
def encode_simple(df):
    hold = pd.concat([df['hjemme'], df['ude']]).unique()
    hold_map = {navn: i for i, navn in enumerate(hold)}
    df['hjemme_enc'] = df['hjemme'].map(hold_map)
    df['ude_enc'] = df['ude'].map(hold_map)
    return df, hold_map

def traen_model(data_path="data/kampe_clean.csv"):
    if not os.path.exists(data_path):
        print("[FEJL] Datafil ikke fundet")
        return

    df = pd.read_csv(data_path)
    df, hold_map = encode_simple(df)

    X = df[["hjemme_enc", "ude_enc"]]
    y = df["result"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("\n[RESULTATER]")
    print(classification_report(y_test, y_pred))

    os.makedirs("models", exist_ok=True)
    joblib.dump((model, hold_map), MODEL_PATH)
    print(f"Model gemt til {MODEL_PATH}")

if __name__ == "__main__":
    traen_model()